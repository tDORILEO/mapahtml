"""
Sistema de Mapeamento Logístico de UCs - Versão Final com Sidebar Funcional
"""

import pandas as pd
import numpy as np
import folium
from sklearn.cluster import DBSCAN
from scipy.spatial import ConvexHull
from shapely.geometry import Point, Polygon
from shapely.strtree import STRtree
import re
import warnings
import os
import pickle
from datetime import datetime
from bs4 import BeautifulSoup

warnings.filterwarnings('ignore')

# =============================================================================
# CONFIGURAÇÕES
# =============================================================================
ARQUIVO_BD_CBA = "bd_cba.txt"
ARQUIVO_FORA_ROTA = "fora_rota.txt"
ARQUIVO_SAIDA = "mapa_ucs.html"
ARQUIVO_CACHE = "cache_estado.pkl"

EPS = 0.008
MIN_SAMPLES = 3
MAX_PONTOS_POR_GRUPO = 3000
EXIBIR_LINHAS_DE_ROTA = False

# =============================================================================
# TABELA DE SEGMENTAÇÃO (COMPLETA)
# =============================================================================
DADOS_SEGMENTACAO = [
    [2, "CUIABA II", "CUIABA", 5, "COXIPÓ", "METROPOLITANA", "Josiane de Souza Miranda Cruz"],
    [4, "COXIPO DA PONTE", "CUIABA", 5, "COXIPÓ", "METROPOLITANA", "Josiane de Souza Miranda Cruz"],
    [76, "COXIPO DO OURO", "CUIABA", 5, "COXIPÓ", "METROPOLITANA", "Josiane de Souza Miranda Cruz"],
    [9, "SANTO ANTONIO DO LEVERGER", "SANTO ANTONIO DO LEVERGER", 5, "COXIPÓ", "METROPOLITANA", "Josiane de Souza Miranda Cruz"],
    [81, "VARGINHA", "SANTO ANTONIO DO LEVERGER", 5, "COXIPÓ", "METROPOLITANA", "Josiane de Souza Miranda Cruz"],
    [178, "ENGENHO VELHO", "SANTO ANTONIO DO LEVERGER", "SANTO ANTONIO DO LEVERGER", "COXIPÓ", "METROPOLITANA", "Josiane de Souza Miranda Cruz"],
    [248, "PALMEIRAS", "SANTO ANTONIO DO LEVERGER", 5, "COXIPÓ", "METROPOLITANA", "Josiane de Souza Miranda Cruz"],
    [249, "MIMOSO", "SANTO ANTONIO DO LEVERGER", 5, "COXIPÓ", "METROPOLITANA", "Josiane de Souza Miranda Cruz"],
    [5, "CUIABA I", "CUIABA", 5, "CUIABÁ", "METROPOLITANA", "Paulo Pleti Gomes"],
    [78, "NOSSA SENHORA DA GUIA", "CUIABA", 5, "CUIABÁ", "METROPOLITANA", "Paulo Pleti Gomes"],
    [450, "CUIABA III", "CUIABA", 5, "CUIABÁ", "METROPOLITANA", "Paulo Pleti Gomes"],
    [21, "NOBRES", "NOBRES", 6, "CUIABÁ", "METROPOLITANA", "Paulo Pleti Gomes"],
    [22, "ROSARIO OESTE", "ROSARIO OESTE", 6, "CUIABÁ", "METROPOLITANA", "Paulo Pleti Gomes"],
    [62, "ACORIZAL", "ACORIZAL", 6, "CUIABÁ", "METROPOLITANA", "Paulo Pleti Gomes"],
    [63, "BAUS", "ACORIZAL", 6, "CUIABÁ", "METROPOLITANA", "Paulo Pleti Gomes"],
    [26, "BRASNORTE", "BRASNORTE", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [122, "COLNIZA", "COLNIZA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [138, "JUARA", "JUARA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [139, "PORTO DOS GAUCHOS", "PORTO DOS GAUCHOS", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [145, "JUINA", "JUINA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [148, "ARIPUANA", "ARIPUANA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [160, "AGUA DA PRATA", "BRASNORTE", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [161, "NOVO HORIZONTE DO NORTE", "NOVO HORIZONTE DO NORTE", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [174, "JURUENA", "JURUENA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [187, "CASTANHEIRA", "CASTANHEIRA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [237, "AMERICANA DO NORTE", "TABAPORA", 145, "JUINA", "SINOP", "Fernanda Bastos"],
    [287, "COTRIGUACU", "COTRIGUACU", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [290, "TERRA ROXA", "JUINA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [291, "TABAPORA", "TABAPORA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [300, "GUARIBA", "COLNIZA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [302, "VILA PARANORTE", "JUARA", 145, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [400, "TRES FRONTEIRAS", "COLNIZA", 28, "JUINA", "TANGARA DA SERRA", "Fernanda Bastos"],
    [33, "JACIARA", "JACIARA", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [34, "DOM AQUINO", "DOM AQUINO", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [91, "JUSCIMEIRA", "JUSCIMEIRA", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [92, "SAO PEDRO DA CIPA", "SAO PEDRO DA CIPA", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [93, "SANTA ELVIRA", "JUSCIMEIRA", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [108, "POXOREU", "POXOREU", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [141, "ALTO COITE", "POXOREU", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [142, "PARANATINGA", "PARANATINGA", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [143, "PARAISO DO LESTE", "POXOREU", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [147, "NOVA BRASILANDIA", "NOVA BRASILANDIA", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [149, "PRIMAVERA DO LESTE", "PRIMAVERA DO LESTE", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [164, "ENTRE RIOS", "DOM AQUINO", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [192, "SAO LOURENCO DE FATIMA", "JUSCIMEIRA", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [194, "CAMPO VERDE", "CAMPO VERDE", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [195, "DISTRITO DE CELMA", "JACIARA", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [241, "AGROVILA JOAO PONCE DE ARRUDA", "CAMPO VERDE", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [266, "PLANALTO DA SERRA", "PLANALTO DA SERRA", 7, "PRIMAVERA DO LESTE", "RONDONOPOLIS", "Edilson Bispo dos Santos"],
    [7, "RONDONOPOLIS", "RONDONOPOLIS", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [10, "ALCANTILADO", "GUIRATINGA", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [12, "GUIRATINGA", "GUIRATINGA", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [16, "BATOVI", "TESOURO", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [42, "PEDRA PRETA", "PEDRA PRETA", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [70, "ALTO GARCAS", "ALTO GARCAS", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [71, "SAO JOSE DO PLANALTO", "PEDRA PRETA", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [90, "BOA VISTA", "RONDONOPOLIS", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [103, "ALTO ARAGUAIA", "ALTO ARAGUAIA", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [105, "ITIQUIRA", "ITIQUIRA", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [106, "TESOURO", "TESOURO", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [144, "SAO JOSE DO POVO", "SAO JOSE DO POVO", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [158, "NOVA GALILEIA", "RONDONOPOLIS", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [186, "VALE RICO", "GUIRATINGA", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [205, "NOVA CATANDUVA", "RONDONOPOLIS", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [208, "ALTO TAQUARI", "ALTO TAQUARI", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [220, "BURITI", "ALTO ARAGUAIA", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [251, "PLANTACOES MICHELIN", "ITIQUIRA", 7, "RONDONOPOLIS", "RONDONOPOLIS", "Cristiano Lima Tomaz"],
    [23, "TAPURAH", "TAPURAH", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [24, "LUCAS DO RIO VERDE", "LUCAS DO RIO VERDE", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [25, "NOVA MUTUM", "NOVA MUTUM", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [53, "UNIAO DO SUL", "UNIAO DO SUL", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [58, "CLAUDIA", "CLAUDIA", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [59, "SINOP", "SINOP", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [60, "MARCELANDIA", "MARCELANDIA", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [167, "SORRISO", "SORRISO", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [171, "SANTA RITA DO TRIVELATO", "SANTA RITA DO TRIVELATO", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [172, "ITANHANGA", "ITANHANGA", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [175, "SANTA CARMEM", "SANTA CARMEM", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [176, "VERA", "VERA", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [198, "IPIRANGA DO NORTE", "IPIRANGA DO NORTE", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [255, "NONOAI DO NORTE", "TERRA NOVA DO NORTE", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [276, "PRIMAVERA", "SORRISO", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [280, "NOVA UBIRATA", "NOVA UBIRATA", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [282, "FELIZ NATAL", "FELIZ NATAL", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [285, "BOA ESPERANCA DO NORTE", "SORRISO", 59, "SINOP", "SINOP", "Alcione Gomes da Silva"],
    [17, "ALTO PARAGUAI", "ALTO PARAGUAI", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [18, "NORTELANDIA", "NORTELANDIA", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [19, "ARENAPOLIS", "ARENAPOLIS", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [20, "DIAMANTINO", "DIAMANTINO", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [27, "BAUXI", "ROSARIO OESTE", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [48, "NOVA FERNANDOPOLIS", "BARRA DO BUGRES", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [54, "SAO JOAQUIM", "TANGARA DA SERRA", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [55, "CAMPO NOVO DO PARECIS", "CAMPO NOVO DO PARECIS", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [66, "BARRA DO BUGRES", "BARRA DO BUGRES", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [73, "TANGARA DA SERRA", "TANGARA DA SERRA", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [94, "SAO JORGE", "TANGARA DA SERRA", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [128, "DENISE", "DENISE", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [129, "PORTO ESTRELA", "PORTO ESTRELA", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [130, "NOVA OLIMPIA", "NOVA OLIMPIA", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [131, "SAPEZAL", "SAPEZAL", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [132, "PROGRESSO", "TANGARA DA SERRA", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [137, "SAO JOSE DO RIO CLARO", "SAO JOSE DO RIO CLARO", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [156, "NOVA MARILANDIA", "NOVA MARILANDIA", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [157, "SANTO AFONSO", "SANTO AFONSO", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [252, "CAPAO VERDE", "ALTO PARAGUAI", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [289, "NOVA MARINGA", "NOVA MARINGA", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [293, "CAMPOS DE JULIO", "CAMPOS DE JULIO", 73, "TANGARA DA SERRA", "TANGARA DA SERRA", "Marcell Duarte Vanderley"],
    [3, "CRISTO REI", "VARZEA GRANDE", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],
    [6, "VARZEA GRANDE", "VARZEA GRANDE", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],
    [35, "POCONE", "POCONE", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],
    [46, "NOSSA SENHORA DO LIVRAMENTO", "NOSSA SENHORA DO LIVRAMENTO", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],
    [65, "JANGADA", "JANGADA", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],
    [82, "PASSAGEM DA CONCEICAO", "VARZEA GRANDE", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],
    [83, "CAPAO GRANDE", "VARZEA GRANDE", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],
    [85, "BOM SUCESSO", "VARZEA GRANDE", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],
    [203, "CANGAS", "POCONE", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],
    [204, "RIBEIRAO DOS COCAIS", "NOSSA SENHORA DO LIVRAMENTO", 6, "VARZEA GRANDE", "METROPOLITANA", "Ariovaldo da Silva Carvalho"],

   # COLE AQUI A LISTA COMPLETA FORNECIDA (140+ itens)
]

df_segmentacao = pd.DataFrame(DADOS_SEGMENTACAO,
                              columns=['cod_area', 'nome_area', 'municipio', 'cod_polo_antigo',
                                       'polo', 'regional', 'gestor'])
df_segmentacao['cod_area'] = df_segmentacao['cod_area'].astype(int)

# =============================================================================
# CORES
# =============================================================================
def hsl_to_hex(h, s, l):
    s = max(0, min(1, s))
    l = max(0, min(1, l))
    c = (1 - abs(2*l - 1)) * s
    h_prime = h / 60
    x = c * (1 - abs(h_prime % 2 - 1))
    m = l - c/2
    if 0 <= h_prime < 1: r, g, b = c, x, 0
    elif 1 <= h_prime < 2: r, g, b = x, c, 0
    elif 2 <= h_prime < 3: r, g, b = 0, c, x
    elif 3 <= h_prime < 4: r, g, b = 0, x, c
    elif 4 <= h_prime < 5: r, g, b = x, 0, c
    else: r, g, b = c, 0, x
    return '#{:02x}{:02x}{:02x}'.format(int((r+m)*255), int((g+m)*255), int((b+m)*255))

cores_urbanas = [hsl_to_hex(180 + (i * 60 / 19), 0.5 + (i % 3) * 0.1, 0.6 + (i % 4) * 0.05) for i in range(19)]
cores_rurais = [hsl_to_hex(0 + (i * 30 / 8) if i < 9 else 330 + ((i-8) * 30 / 8), 0.8 + (i % 3) * 0.1, 0.6 + (i % 3) * 0.1) for i in range(17)]
cores_excesso = [hsl_to_hex((i * 360 / 29), 0.2 + (i % 3) * 0.1, 0.2 + (i % 4) * 0.05) for i in range(29)]

COR_POR_LIVRO = {}
for i, livro in enumerate(range(1, 20)): COR_POR_LIVRO[livro] = cores_urbanas[i % len(cores_urbanas)]
for i, livro in enumerate(range(41, 58)): COR_POR_LIVRO[livro] = cores_rurais[i % len(cores_rurais)]
for i, livro in enumerate(range(71, 100)): COR_POR_LIVRO[livro] = cores_excesso[i % len(cores_excesso)]
for livro in range(100):
    if livro not in COR_POR_LIVRO:
        COR_POR_LIVRO[livro] = "#888888"

def gerar_cor_area(area_id):
    np.random.seed(area_id)
    r = np.random.randint(100, 200)
    g = np.random.randint(100, 200)
    b = np.random.randint(100, 200)
    return '#{:02x}{:02x}{:02x}'.format(r, g, b)

# =============================================================================
# FUNÇÕES AUXILIARES
# =============================================================================
def converter_coord(val):
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        val = val.replace(',', '.')
        try:
            return float(val)
        except:
            return np.nan
    return np.nan

def gerar_poligonos_otimizado(df_base, col_agrup, eps, min_samples, max_pts=MAX_PONTOS_POR_GRUPO):
    resultados = []
    for grupo_val, grupo in df_base.groupby(col_agrup):
        pontos = grupo[['latitude','longitude']].values
        if len(pontos) < 3:
            continue
        if len(pontos) > max_pts:
            indices = np.random.choice(len(pontos), max_pts, replace=False)
            pontos = pontos[indices]
        try:
            clustering = DBSCAN(eps=eps, min_samples=min_samples, algorithm='ball_tree', n_jobs=-1).fit(pontos)
            labels = clustering.labels_
        except:
            labels = np.zeros(len(pontos))
        for label in set(labels):
            if label == -1:
                continue
            cluster = pontos[labels == label]
            if len(cluster) < 3:
                continue
            try:
                hull = ConvexHull(cluster)
                vertices = cluster[hull.vertices]
                coords = [[lat, lon] for lat, lon in vertices]
                coords.append(coords[0])
                resultados.append({
                    'grupo': grupo_val if len(col_agrup) > 1 else (grupo_val,),
                    'coords': coords,
                })
            except:
                continue
    return resultados

def carregar_dados_txt():
    colunas_bd = ['livro', 'codlcd', 'rota', 'uc', 'bairro', 'latitude', 'longitude']
    df_bd = pd.read_csv(ARQUIVO_BD_CBA, sep=';', header=None, names=colunas_bd,
                        dtype={'uc': str}, encoding='utf-8-sig', skip_blank_lines=True)
    df_bd['latitude'] = df_bd['latitude'].apply(converter_coord)
    df_bd['longitude'] = df_bd['longitude'].apply(converter_coord)
    df_bd.dropna(subset=['latitude','longitude'], inplace=True)
    df_bd = df_bd[(df_bd['latitude'].between(-90,90)) & (df_bd['longitude'].between(-180,180))]
    df_bd['area'] = df_bd['codlcd'].astype(int)
    df_bd['endereco'] = df_bd['bairro'].astype(str)
    df_bd['base'] = 'BD_CBA'
    df_bd['codirr'] = ''

    colunas_fora = ['polo_txt', 'uc', 'livro', 'codlcd', 'rota', 'numcta',
                    'bairro', 'nomemun', 'numano', 'nummes', 'codirr',
                    'latitude', 'longitude']
    df_fora = pd.read_csv(ARQUIVO_FORA_ROTA, sep=';', header=None, names=colunas_fora,
                          dtype={'uc': str, 'codirr': str}, encoding='utf-8-sig',
                          skip_blank_lines=True)
    df_fora['latitude'] = df_fora['latitude'].apply(converter_coord)
    df_fora['longitude'] = df_fora['longitude'].apply(converter_coord)
    df_fora.dropna(subset=['latitude','longitude'], inplace=True)
    df_fora['area'] = df_fora['codlcd'].astype(int)
    df_fora['endereco'] = df_fora['bairro'].astype(str)
    df_fora['base'] = 'FORA_ROTA'
    df_fora['livro'] = df_fora['livro'].astype(int)
    df_fora['rota'] = df_fora['rota'].astype(int)

    return df_bd, df_fora

def consolidar_dados(df_bd, df_fora):
    df_todas = pd.concat([df_bd, df_fora], ignore_index=True)
    df_todas = df_todas.merge(df_segmentacao[['cod_area', 'polo', 'nome_area']],
                              left_on='area', right_on='cod_area', how='left')
    df_todas = df_todas.dropna(subset=['polo'])
    return df_todas

def detectar_alteracoes(df_atual, df_anterior):
    if df_anterior is None:
        areas = set(df_atual['area'].unique())
        roteiros = set(tuple(x) for x in df_atual[['livro','area','rota']].drop_duplicates().values)
        return areas, roteiros

    colunas_id = ['uc', 'base']
    colunas_mutaveis = ['latitude', 'longitude', 'livro', 'area', 'rota']

    df_ant = df_anterior[colunas_id + colunas_mutaveis].copy()
    df_at = df_atual[colunas_id + colunas_mutaveis].copy()

    merged = df_at.merge(df_ant, on=colunas_id, how='outer', suffixes=('_atual', '_antiga'), indicator=True)

    novas = merged[merged['_merge'] == 'left_only']
    removidas = merged[merged['_merge'] == 'right_only']
    alteradas = merged[merged['_merge'] == 'both']
    mask_alt = pd.Series(False, index=alteradas.index)
    for col in colunas_mutaveis:
        mask_alt |= (alteradas[col+'_atual'] != alteradas[col+'_antiga'])
    alteradas = alteradas[mask_alt]

    areas_afetadas = set()
    roteiros_afetados = set()

    for df_temp in [novas, removidas, alteradas]:
        if df_temp.empty:
            continue
        if '_merge' in df_temp.columns and (df_temp['_merge'] == 'right_only').any():
            sub = df_temp[df_temp['_merge'] == 'right_only']
            areas_afetadas.update(sub['area_antiga'].dropna().astype(int))
            roteiros = sub[['livro_antiga','area_antiga','rota_antiga']].dropna().astype(int)
            roteiros_afetados.update(tuple(x) for x in roteiros.values)
        else:
            sub = df_temp[df_temp['_merge'] != 'right_only'] if '_merge' in df_temp.columns else df_temp
            col_area = 'area' if 'area' in sub.columns else 'area_atual'
            areas_afetadas.update(sub[col_area].dropna().astype(int))
            cols_rot = ['livro','area','rota']
            if all(c in sub.columns for c in cols_rot):
                rot_data = sub[cols_rot].dropna().astype(int)
            else:
                rot_data = sub[[c+'_atual' for c in cols_rot]].dropna().astype(int)
                rot_data.columns = cols_rot
            roteiros_afetados.update(tuple(x) for x in rot_data.values)

    return areas_afetadas, roteiros_afetados

# =============================================================================
# PROCESSAMENTO PRINCIPAL
# =============================================================================
def main():
    print(f"Iniciando processamento em {datetime.now()}...")

    df_bd, df_fora = carregar_dados_txt()
    df_atual = consolidar_dados(df_bd, df_fora)
    print(f"UCs atuais: {len(df_atual)}")

    if df_atual.empty:
        print("Nenhuma UC válida. Gerando mapa vazio.")
        folium.Map(location=[-15.6, -56.1], zoom_start=10).save(ARQUIVO_SAIDA)
        return

    # Cache
    cache = None
    if os.path.exists(ARQUIVO_CACHE):
        try:
            with open(ARQUIVO_CACHE, 'rb') as f:
                cache = pickle.load(f)
        except:
            cache = None

    df_anterior = cache['df_completo'] if cache else None
    poligonos_area_cache = cache.get('poligonos_area', []) if cache else []
    poligonos_livro_cache = cache.get('poligonos_livro', []) if cache else []

    areas_afetadas, roteiros_afetados = detectar_alteracoes(df_atual, df_anterior)
    print(f"Áreas com alterações: {len(areas_afetadas)}")
    print(f"Roteiros com alterações: {len(roteiros_afetados)}")

    if areas_afetadas:
        df_areas_afetadas = df_atual[df_atual['area'].isin(areas_afetadas)]
        novos_poligonos_area = gerar_poligonos_otimizado(df_areas_afetadas, ['area'], EPS, MIN_SAMPLES)
        poligonos_area = [p for p in poligonos_area_cache if p['grupo'][0] not in areas_afetadas]
        poligonos_area.extend(novos_poligonos_area)
    else:
        poligonos_area = poligonos_area_cache

    if roteiros_afetados:
        mask_rot = pd.Series(False, index=df_atual.index)
        for livro, area, rota in roteiros_afetados:
            mask_rot |= ((df_atual['livro'] == livro) & (df_atual['area'] == area) & (df_atual['rota'] == rota))
        df_rot_afetados = df_atual[mask_rot]
        novos_poligonos_livro = gerar_poligonos_otimizado(df_rot_afetados, ['livro','area'], EPS, MIN_SAMPLES)
        chaves_afetadas = set((l, a) for l, a, _ in roteiros_afetados)
        poligonos_livro = [p for p in poligonos_livro_cache if (p['grupo'][0], p['grupo'][1]) not in chaves_afetadas]
        poligonos_livro.extend(novos_poligonos_livro)
    else:
        poligonos_livro = poligonos_livro_cache

    print(f"Polígonos de área: {len(poligonos_area)}")
    print(f"Polígonos de livro: {len(poligonos_livro)}")

    cache_novo = {
        'df_completo': df_atual,
        'poligonos_area': poligonos_area,
        'poligonos_livro': poligonos_livro,
        'timestamp': datetime.now()
    }
    with open(ARQUIVO_CACHE, 'wb') as f:
        pickle.dump(cache_novo, f, protocol=4)

    # Conflitos
    conflitos = []
    df_fora_com_polo = df_atual[df_atual['base'] == 'FORA_ROTA']
    if not df_fora_com_polo.empty and poligonos_livro:
        pol_geoms = []
        pol_info = []
        for p in poligonos_livro:
            try:
                poly = Polygon(p['coords'])
                if poly.is_valid and not poly.is_empty:
                    pol_geoms.append(poly)
                    pol_info.append(p)
            except:
                continue
        if pol_geoms:
            tree = STRtree(pol_geoms)
            for _, row in df_fora_com_polo.iterrows():
                pt = Point(row['latitude'], row['longitude'])
                indices = tree.query(pt)
                for idx in indices:
                    geom = pol_geoms[idx]
                    if geom.contains(pt):
                        grupo = pol_info[idx]['grupo']
                        livro_c, area_c = grupo
                        if row['livro'] != livro_c or row['area'] != area_c:
                            conflitos.append({
                                'uc': row['uc'],
                                'livro_informado': row['livro'],
                                'area_informada': row['area'],
                                'livro_correto': livro_c,
                                'area_correta': area_c,
                                'latitude': row['latitude'],
                                'longitude': row['longitude'],
                                'base': 'FORA_ROTA',
                                'codirr': row.get('codirr', '')
                            })
                        break

    # ========== CONSTRUÇÃO DO MAPA ==========
    print("Construindo mapa...")
    centro_lat = df_atual['latitude'].mean()
    centro_lon = df_atual['longitude'].mean()
    if pd.isna(centro_lat):
        centro_lat, centro_lon = -15.6, -56.1

    mapa = folium.Map(location=[centro_lat, centro_lon], zoom_start=10, control_scale=True)

    # Áreas
    if poligonos_area:
        area_group = folium.FeatureGroup(name="Áreas", show=True)
        cores_area = {}
        for p in poligonos_area:
            aid = p['grupo'][0]
            if aid not in cores_area:
                cores_area[aid] = gerar_cor_area(aid)
            info = df_segmentacao[df_segmentacao['cod_area'] == aid]
            nome = info['nome_area'].iloc[0] if not info.empty else f"Área {aid}"
            polo = df_atual[df_atual['area'] == aid]['polo'].iloc[0] if not df_atual[df_atual['area'] == aid].empty else ''
            folium.Polygon(
                locations=p['coords'],
                color=cores_area[aid],
                weight=4,
                fill=False,
                popup=f"<b>{nome}</b><br>Código: {aid}<br>Polo: {polo}",
                tooltip=f"Área {nome} ({aid})"
            ).add_to(area_group)
        area_group.add_to(mapa)

    # Livros
    if poligonos_livro:
        livro_group = folium.FeatureGroup(name="Livros", show=True)
        for p in poligonos_livro:
            livro, aid = p['grupo']
            cor = COR_POR_LIVRO.get(livro, "#888888")
            info = df_segmentacao[df_segmentacao['cod_area'] == aid]
            nome = info['nome_area'].iloc[0] if not info.empty else f"Área {aid}"
            polo = df_atual[(df_atual['livro'] == livro) & (df_atual['area'] == aid)]['polo'].iloc[0] if not df_atual[(df_atual['livro'] == livro) & (df_atual['area'] == aid)].empty else ''
            folium.Polygon(
                locations=p['coords'],
                color=cor,
                weight=2,
                fill=True,
                fill_color=cor,
                fill_opacity=0.25,
                popup=f"<b>Livro {livro}</b><br>Área: {nome} ({aid})<br>Polo: {polo}",
                tooltip=f"Livro {livro} - {nome}"
            ).add_to(livro_group)
        livro_group.add_to(mapa)

    # Pontos BD_CBA (amostra)
    df_bd_plot = df_atual[df_atual['base'] == 'BD_CBA']
    if len(df_bd_plot) > 10000:
        df_bd_plot = df_bd_plot.sample(10000, random_state=42)
    if not df_bd_plot.empty:
        bd_group = folium.FeatureGroup(name="UCs BD_CBA", show=True)
        for _, row in df_bd_plot.iterrows():
            cor = COR_POR_LIVRO.get(row['livro'], "#888888")
            folium.CircleMarker(
                location=[row['latitude'], row['longitude']],
                radius=5,
                color=cor,
                fill=True,
                fillColor=cor,
                fillOpacity=0.7,
                popup=folium.Popup(
                    f"<b>UC:</b> {row['uc']}<br>"
                    f"<b>Roteiro:</b> {row['livro']}/{row['area']}/{row['rota']}<br>"
                    f"<b>Localidade:</b> {row['nome_area']}<br>"
                    f"<b>Polo:</b> {row['polo']}<br>"
                    f"<b>Endereço:</b> {row['endereco']}",
                    max_width=300
                ),
                tooltip=f"BD_CBA {row['uc']}"
            ).add_to(bd_group)
        bd_group.add_to(mapa)

    # Pontos FORA_ROTA
    if not df_fora_com_polo.empty:
        fora_group = folium.FeatureGroup(name="UCs FORA_ROTA", show=True)
        for _, row in df_fora_com_polo.iterrows():
            conflito = next((c for c in conflitos if c['uc'] == row['uc']), None)
            codirr_text = f"<br><b>CODIRR:</b> {row['codirr']}" if pd.notna(row['codirr']) and row['codirr'] != '' else ""
            if conflito:
                popup_text = (f"<b style='color:red;'>CONFLITO!</b><br>"
                              f"<b>UC:</b> {row['uc']}<br>"
                              f"<b>Informado:</b> {row['livro']}/{row['area']}<br>"
                              f"<b>Correto:</b> {conflito['livro_correto']}/{conflito['area_correta']}"
                              f"{codirr_text}")
                folium.CircleMarker(
                    location=[row['latitude'], row['longitude']],
                    radius=9,
                    color='red',
                    weight=3,
                    fill=True,
                    fillColor='red',
                    fillOpacity=0.9,
                    popup=folium.Popup(popup_text, max_width=300),
                    tooltip=f"⚠️ CONFLITO: {row['uc']}"
                ).add_to(fora_group)
            else:
                cor = COR_POR_LIVRO.get(row['livro'], "#888888")
                icon_html = f'''
                    <div style="width: 0; height: 0;
                                border-left: 10px solid transparent;
                                border-right: 10px solid transparent;
                                border-bottom: 18px solid {cor};
                                filter: drop-shadow(1px 1px 1px rgba(0,0,0,0.3));">
                    </div>
                '''
                icon = folium.DivIcon(html=icon_html, icon_size=(20, 18), icon_anchor=(10, 18))
                popup_text = (f"<b>FORA_ROTA</b><br>"
                              f"<b>UC:</b> {row['uc']}<br>"
                              f"<b>Roteiro:</b> {row['livro']}/{row['area']}/{row['rota']}<br>"
                              f"<b>Localidade:</b> {row['nome_area']}<br>"
                              f"<b>Polo:</b> {row['polo']}<br>"
                              f"<b>Endereço:</b> {row['endereco']}{codirr_text}")
                folium.Marker(
                    location=[row['latitude'], row['longitude']],
                    icon=icon,
                    popup=folium.Popup(popup_text, max_width=300),
                    tooltip=f"FORA_ROTA {row['uc']}"
                ).add_to(fora_group)
        fora_group.add_to(mapa)

    folium.LayerControl().add_to(mapa)

    # Dropdown de polo
    todos_polos = sorted(df_segmentacao['polo'].unique())
    map_name = mapa.get_name()
    options_html = ''.join(f'<option value="{p}">{p}</option>' for p in todos_polos)
    dropdown_html = fr'''
    <div style="position:fixed; top:10px; right:10px; z-index:1000; background:white; padding:10px; border-radius:5px; border:1px solid #ccc; box-shadow:2px 2px 5px rgba(0,0,0,0.2);">
        <label for="polo-select"><b>Filtrar por Polo:</b></label>
        <select id="polo-select" style="margin-left:5px; padding:5px;">
            <option value="todos">Todos os Polos</option>
            {options_html}
        </select>
    </div>
    <script>
    (function(){{
        var map = {map_name};
        var groups = [];
        map.eachLayer(l => {{ if(l instanceof L.FeatureGroup) groups.push(l); }});
        function filter(polo){{
            groups.forEach(g => g.eachLayer(l => {{
                var popup = l.getPopup();
                if(popup){{
                    var content = popup.getContent();
                    var match = content.match(/Polo:<\/b> (.*?)<br>/);
                    var layerPolo = match ? match[1] : '';
                    if(polo === 'todos' || layerPolo === polo){{
                        if(l.setStyle) l.setStyle({{opacity:1, fillOpacity:0.25}});
                        else if(l.setRadius) l.setRadius(5);
                    }}else{{
                        if(l.setStyle) l.setStyle({{opacity:0, fillOpacity:0}});
                        else if(l.setRadius) l.setRadius(0);
                    }}
                }}
            }}));
        }}
        document.getElementById('polo-select').addEventListener('change', e => filter(e.target.value));
        filter('todos');
    }})();
    </script>
    '''
    mapa.get_root().html.add_child(folium.Element(dropdown_html))

    # ========== SALVAR E INJETAR SIDEBAR COM BEAUTIFULSOUP ==========
    temp_html = "temp_map.html"
    mapa.save(temp_html)

    with open(temp_html, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f, 'html.parser')

    num_ucs = len(df_atual[df_atual['base'] == 'BD_CBA'])
    num_polos = df_segmentacao['polo'].nunique()
    num_areas = df_atual['area'].nunique()
    num_conflitos = len(conflitos)
    livros_presentes = sorted(df_atual['livro'].unique())

    # Construir HTML da sidebar
    sidebar_content = f'''
    <div class="sidebar">
        <div class="sidebar-header">
            <h1><i class="fas fa-map-marked-alt"></i> Logística UCs</h1>
            <p>Gestão de Unidades Consumidoras</p>
        </div>
        <div class="stats-grid">
            <div class="stat-card"><div class="number">{num_ucs}</div><div class="label">UCs BD_CBA</div></div>
            <div class="stat-card"><div class="number">{num_polos}</div><div class="label">Polos</div></div>
            <div class="stat-card"><div class="number">{num_areas}</div><div class="label">Localidades</div></div>
            <div class="stat-card"><div class="number" style="color:#c7254e;">{num_conflitos}</div><div class="label">Conflitos</div></div>
        </div>
        <div class="legend-section">
            <div class="legend-title"><i class="fas fa-info-circle"></i> Legenda</div>
            <div class="legend-item"><div class="legend-symbol"><i class="fas fa-circle" style="color:#2c7da0; font-size:14px;"></i></div><div class="legend-text"><strong>BD_CBA</strong> – UCs da base</div></div>
            <div class="legend-item"><div class="legend-symbol"><i class="fas fa-play" style="color:#e9a23b; font-size:14px; transform:rotate(270deg);"></i></div><div class="legend-text"><strong>FORA_ROTA</strong> – UCs com indicador 87</div></div>
            <div class="legend-item"><div class="legend-symbol"><span style="display:inline-block; width:14px; height:14px; background-color:red; border-radius:50%;"></span></div><div class="legend-text"><strong>Conflito</strong> – Roteiro incorreto</div></div>
            <div class="legend-item"><div class="legend-symbol"><span style="display:inline-block; width:18px; height:3px; background:linear-gradient(90deg, red, green, blue); vertical-align:middle;"></span></div><div class="legend-text"><strong>Área</strong> – Fronteira colorida</div></div>
        </div>
        <div class="legend-section">
            <div class="legend-title"><i class="fas fa-book"></i> Livros</div>
            <div class="book-colors">
    '''
    for livro in livros_presentes:
        cor = COR_POR_LIVRO.get(livro, "#888888")
        sidebar_content += f'<div class="book-item"><div class="book-color" style="background-color:{cor};"></div><span>Livro {livro}</span></div>'
    sidebar_content += f'''
            </div>
        </div>
        <div class="footer-note">
            <i class="fas fa-sync-alt"></i> Atualizado em {datetime.now().strftime('%d/%m/%Y %H:%M')}<br>
            Use o controle de camadas e o seletor de polo.
        </div>
    </div>
    '''

    # CSS da sidebar
    style_css = '''
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Roboto, sans-serif; background: #f0f2f5; overflow: hidden; }
        .app-container { display: flex; width: 100vw; height: 100vh; overflow: hidden; }
        .sidebar {
            width: 320px; background: linear-gradient(145deg, #ffffff 0%, #f8f9fc 100%);
            box-shadow: 4px 0 20px rgba(0,0,0,0.08); z-index: 1001; display: flex;
            flex-direction: column; overflow-y: auto; border-right: 1px solid rgba(0,0,0,0.05);
        }
        .sidebar-header { padding: 24px 20px 16px; border-bottom: 1px solid #e9ecef; background: #ffffff; }
        .sidebar-header h1 { font-size: 1.6rem; font-weight: 600; color: #1e2a3a; margin-bottom: 6px; display: flex; align-items: center; gap: 8px; }
        .stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; padding: 16px 20px; background: #ffffff; border-bottom: 1px solid #eef2f6; }
        .stat-card { background: #f8fafd; border-radius: 16px; padding: 12px 8px; text-align: center; border: 1px solid #eef2f6; }
        .stat-card .number { font-size: 1.8rem; font-weight: 700; color: #1e466e; line-height: 1.2; }
        .stat-card .label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; color: #5a6e7c; margin-top: 6px; }
        .legend-section { padding: 16px 20px; border-bottom: 1px solid #eef2f6; }
        .legend-title { font-weight: 600; font-size: 0.9rem; color: #1e2a3a; margin-bottom: 14px; display: flex; align-items: center; gap: 8px; border-left: 3px solid #2c7da0; padding-left: 10px; }
        .legend-item { display: flex; align-items: center; margin-bottom: 12px; font-size: 0.8rem; color: #2c3e44; }
        .legend-symbol { width: 28px; text-align: center; margin-right: 10px; }
        .book-colors { max-height: 240px; overflow-y: auto; margin-top: 8px; }
        .book-item { display: flex; align-items: center; margin-bottom: 8px; font-size: 0.75rem; }
        .book-color { width: 18px; height: 12px; border-radius: 3px; margin-right: 10px; border: 0.5px solid #ccc; }
        .footer-note { padding: 16px 20px 24px; font-size: 0.7rem; color: #8a9aa8; text-align: center; background: #fcfcfd; border-top: 1px solid #eef2f6; margin-top: auto; }
        .map-container { flex: 1; position: relative; background: #e9ecef; }
        .folium-map { width: 100%; height: 100%; }
        @media (max-width: 768px) {
            .sidebar { width: 260px; position: absolute; left: -260px; transition: left 0.3s; height: 100%; z-index: 2000; }
            .sidebar.open { left: 0; }
            .map-container { width: 100%; }
        }
        .sidebar::-webkit-scrollbar { width: 5px; }
        .sidebar::-webkit-scrollbar-track { background: #eef2f6; }
        .sidebar::-webkit-scrollbar-thumb { background: #b9c4ce; border-radius: 4px; }
    </style>
    '''

    # Substituir o body
    original_body = soup.body
    new_body = soup.new_tag('body')
    app_container = soup.new_tag('div', **{'class': 'app-container'})
    app_container.append(BeautifulSoup(sidebar_content, 'html.parser'))
    map_container = soup.new_tag('div', **{'class': 'map-container'})
    map_div = original_body.find('div', class_='folium-map')
    if map_div:
        map_container.append(map_div)
    app_container.append(map_container)
    new_body.append(app_container)
    original_body.replace_with(new_body)

    # Adicionar Font Awesome e CSS ao head
    head = soup.head
    fa_link = soup.new_tag('link', rel='stylesheet', href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css')
    head.append(fa_link)
    style_tag = BeautifulSoup(style_css, 'html.parser')
    head.append(style_tag)

    # Salvar arquivo final
    with open(ARQUIVO_SAIDA, 'w', encoding='utf-8') as f:
        f.write(str(soup))

    os.remove(temp_html)
    print(f"Mapa salvo com sucesso: {ARQUIVO_SAIDA}")

if __name__ == "__main__":
    main()