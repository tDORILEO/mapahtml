import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading
import pandas as pd
import numpy as np
import folium
from folium.plugins import MarkerCluster, MiniMap, Fullscreen, LocateControl
from sklearn.cluster import DBSCAN
from scipy.spatial import ConvexHull
from shapely.geometry import Point, Polygon
from shapely.strtree import STRtree
import warnings
import logging
import os
import json
from datetime import datetime

warnings.filterwarnings('ignore')

# =============================================================================
# LOGGING
# =============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler("mapa_uc.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)

# =============================================================================
# CONFIGURAÇÕES GLOBAIS
# =============================================================================
EPS_DEFAULT   = 0.008
MIN_SAMPLES_DEFAULT = 3

# Paleta de cores distinta por livro (urbano 1-19, rural 41-57)
_PALETA_URB = ["#1f77b4","#2ca02c","#17becf","#9467bd","#8c564b",
               "#e377c2","#7f7f7f","#bcbd22","#0d6efd","#20c997"]
_PALETA_RUR = ["#ff7f0e","#d62728","#f0a500","#a05195","#665191",
               "#2f4b7c","#f95d6a","#ff7c43","#ffa600","#d45087"]

COR_POR_LIVRO = {}
for i, livro in enumerate(range(1, 40)):
    COR_POR_LIVRO[livro] = _PALETA_URB[i % len(_PALETA_URB)]
for i, livro in enumerate(range(40, 80)):
    COR_POR_LIVRO[livro] = _PALETA_RUR[i % len(_PALETA_RUR)]

# =============================================================================
# UTILITÁRIOS
# =============================================================================

def converter_coord(val):
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        val = val.replace(',', '.')
        try:
            return float(val)
        except Exception:
            return np.nan
    return np.nan


def extrair_livro_area(roteiro):
    if not isinstance(roteiro, str):
        return (0, 0)
    partes = roteiro.split('/')
    if len(partes) >= 2:
        try:
            return (int(partes[0]), int(partes[1]))
        except Exception:
            pass
    return (0, 0)


def _auto_map(colunas, candidatos):
    """Tenta casar um nome de coluna com lista de candidatos (case-insensitive, strip)."""
    upper_cols = {c.upper().strip(): c for c in colunas}
    for cand in candidatos:
        if cand.upper() in upper_cols:
            return upper_cols[cand.upper()]
    return None

# =============================================================================
# PROCESSAMENTO GEOESPACIAL
# =============================================================================

def gerar_poligonos(df_base, col_agrup, eps, min_samples):
    """Gera polígonos convexos por grupo usando DBSCAN."""
    resultados = []
    for grupo_val, grupo in df_base.groupby(col_agrup):
        pontos = grupo[['latitude', 'longitude']].values
        if len(pontos) < 3:
            continue
        clustering = DBSCAN(eps=eps, min_samples=min_samples).fit(pontos)
        for label in set(clustering.labels_):
            if label == -1:
                continue
            cluster = pontos[clustering.labels_ == label]
            if len(cluster) < 3:
                continue
            try:
                hull = ConvexHull(cluster)
                vertices = cluster[hull.vertices]
                coords = [[lat, lon] for lat, lon in vertices]
                coords.append(coords[0])
                centro = (cluster[:, 0].mean(), cluster[:, 1].mean())
                resultados.append({
                    'grupo': grupo_val if isinstance(grupo_val, tuple) else (grupo_val,),
                    'coords': coords,
                    'centro': centro
                })
            except Exception as e:
                log.debug(f"ConvexHull falhou para grupo {grupo_val}: {e}")
    return resultados


def verificar_conflitos(pontos_df, poligonos_livro):
    """Verifica se UCs estão dentro de polígonos de livro errado."""
    if not poligonos_livro:
        return []

    pol_geoms = [Polygon(p['coords']) for p in poligonos_livro]
    # Filtra polígonos inválidos
    validos = [(g, p) for g, p in zip(pol_geoms, poligonos_livro) if g.is_valid]
    if not validos:
        return []
    pol_geoms_v, pol_info_v = zip(*validos)
    tree = STRtree(list(pol_geoms_v))

    conflitos = []
    for _, ponto in pontos_df.iterrows():
        pt = Point(ponto['latitude'], ponto['longitude'])
        indices = tree.query(pt, predicate='contains')
        for idx in indices:
            pol_info = pol_info_v[idx]
            livro_correto = pol_info['grupo'][0]
            if ponto['livro'] != livro_correto:
                conflitos.append({
                    'uc':             ponto['uc'],
                    'endereco':       ponto['endereco'],
                    'livro_informado':ponto['livro'],
                    'livro_correto':  livro_correto,
                    'area':           pol_info['grupo'][1] if len(pol_info['grupo']) > 1 else None,
                    'latitude':       ponto['latitude'],
                    'longitude':      ponto['longitude'],
                    'base':           ponto['base']
                })
            break
    return conflitos

# =============================================================================
# EXPORTAÇÃO DE RELATÓRIO
# =============================================================================

def exportar_relatorio(conflitos, df_bd, saida_html):
    """Gera Excel com: aba Conflitos, aba Resumo por polo/livro."""
    if not conflitos and df_bd.empty:
        return None

    saida_xlsx = saida_html.replace('.html', '_relatorio.xlsx')
    try:
        with pd.ExcelWriter(saida_xlsx, engine='openpyxl') as writer:
            # Aba conflitos
            if conflitos:
                df_conf = pd.DataFrame(conflitos)
                df_conf.columns = ['UC', 'Endereço', 'Livro Informado', 'Livro Correto',
                                   'Área', 'Latitude', 'Longitude', 'Base']
                df_conf.to_excel(writer, sheet_name='Conflitos', index=False)

                # Formatar planilha de conflitos
                ws = writer.sheets['Conflitos']
                for col in ws.columns:
                    max_len = max(len(str(cell.value or '')) for cell in col)
                    ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 40)

            # Aba resumo por polo e livro
            if not df_bd.empty:
                resumo = (df_bd.groupby(['polo', 'livro'])
                          .agg(total_ucs=('uc', 'count'))
                          .reset_index())
                resumo.columns = ['Polo', 'Livro', 'Total UCs']
                resumo.to_excel(writer, sheet_name='Resumo_Polo_Livro', index=False)

            # Aba estatísticas gerais
            stats = {
                'Métrica': ['Total UCs BD_CBA', 'Total Conflitos', 'Data/Hora Geração'],
                'Valor':   [
                    len(df_bd) if not df_bd.empty else 0,
                    len(conflitos),
                    datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                ]
            }
            pd.DataFrame(stats).to_excel(writer, sheet_name='Estatísticas', index=False)

        log.info(f"Relatório exportado: {saida_xlsx}")
        return saida_xlsx
    except Exception as e:
        log.error(f"Erro ao exportar relatório: {e}")
        return None

def _render_conflitos_html(conflitos, total_conf):
    if total_conf == 0:
        return ''
    itens = []
    for c in conflitos[:50]:
        lat = c['latitude']
        lon = c['longitude']
        uc  = c['uc']
        base = c['base']
        liv_inf = c['livro_informado']
        liv_cor = c['livro_correto']
        item = (
            f'<div class="conf-item" onclick="irParaConflito({lat},{lon})">'
            f'<b>{uc}</b> ({base})<br>'
            f'Livro {liv_inf} &rarr; Correto: {liv_cor}'
            f'</div>'
        )
        itens.append(item)
    extra = f'...<br><small>Mostrando 50 de {total_conf}</small>' if total_conf > 50 else ''
    return (
        f'<div class="secao-titulo">&#9888;&#65039; Conflitos ({total_conf})</div>'
        f'<div id="lista-conflitos">{"".join(itens)}{extra}</div>'
    )


# =============================================================================
# CONSTRUÇÃO DO MAPA
# =============================================================================

def construir_mapa(df_bd, df_comp, todos_poligonos_area, todos_poligonos_livro,
                   conflitos, df_seg, params):
    """Constrói e retorna o mapa folium."""

    centro_lat = df_bd['latitude'].mean()
    centro_lon = df_bd['longitude'].mean()

    mapa = folium.Map(
        location=[centro_lat, centro_lon],
        zoom_start=11,
        control_scale=True,
        tiles=None
    )

    # --- Camadas base ---
    folium.TileLayer('CartoDB positron', name='Mapa Claro', control=True).add_to(mapa)
    folium.TileLayer('CartoDB dark_matter', name='Mapa Escuro', control=True).add_to(mapa)
    folium.TileLayer('OpenStreetMap', name='OpenStreetMap', control=True).add_to(mapa)

    # --- Plugins ---
    Fullscreen(position='topleft').add_to(mapa)
    MiniMap(toggle_display=True).add_to(mapa)

    # --- Grupos de camada ---
    grp_areas      = folium.FeatureGroup(name='📦 Polígonos de Área', show=True)
    grp_livros     = folium.FeatureGroup(name='📚 Polígonos de Livro', show=True)
    grp_bd         = folium.FeatureGroup(name='🔵 UCs BD_CBA', show=True)
    grp_comp_ok    = folium.FeatureGroup(name='✅ UCs Comparação (OK)', show=True)
    grp_conflitos  = folium.FeatureGroup(name='⚠️ Conflitos', show=True)

    # --- Polígonos de Área (borda preta) ---
    for p in todos_poligonos_area:
        folium.Polygon(
            locations=p['coords'],
            color='#222222', weight=3, fill=False,
            popup=folium.Popup(
                f"<b>Área {p['area_id']}</b><br>{p['nome_area']}<br>Polo: {p['polo']}",
                max_width=200
            ),
            tooltip=f"Área {p['area_id']} – {p['nome_area']}"
        ).add_to(grp_areas)

    # --- Polígonos de Livro (coloridos) ---
    for p in todos_poligonos_livro:
        cor = COR_POR_LIVRO.get(p['livro'], '#888888')
        folium.Polygon(
            locations=p['coords'],
            color=cor, weight=1.5, fill=True,
            fill_color=cor, fill_opacity=0.2,
            popup=folium.Popup(
                f"<b>Livro {p['livro']}</b><br>Área {p['area_id']}<br>Polo: {p['polo']}",
                max_width=200
            ),
            tooltip=f"Livro {p['livro']} | Área {p['area_id']}"
        ).add_to(grp_livros)

    # --- UCs BD_CBA com cluster ---
    cluster_bd = MarkerCluster(name='Cluster BD', show=False).add_to(grp_bd)
    for _, row in df_bd.iterrows():
        cor = COR_POR_LIVRO.get(row['livro'], '#888888')
        popup_html = f"""
        <div style='font-family:sans-serif;font-size:12px;min-width:180px'>
          <b>UC:</b> {row['uc']}<br>
          <b>Livro:</b> {row['livro']} &nbsp;|&nbsp; <b>Área:</b> {row['area']}<br>
          <b>Polo:</b> {row.get('polo','')}<br>
          <b>Endereço:</b> {row['endereco']}<br>
          <b>Lat/Lon:</b> {row['latitude']:.6f}, {row['longitude']:.6f}
        </div>"""
        folium.CircleMarker(
            location=[row['latitude'], row['longitude']],
            radius=5, color=cor, fill=True,
            fill_color=cor, fill_opacity=0.85, weight=1,
            tooltip=f"UC {row['uc']} | Livro {row['livro']}",
            popup=folium.Popup(popup_html, max_width=220)
        ).add_to(cluster_bd)

    # --- UCs de Comparação ---
    conflito_set = {(c['uc'], c['base']) for c in conflitos}
    conflito_map = {(c['uc'], c['base']): c for c in conflitos}

    for _, row in df_comp.iterrows():
        chave = (row['uc'], row['base'])
        cor = COR_POR_LIVRO.get(row['livro'], '#888888')

        if chave in conflito_set:
            c = conflito_map[chave]
            popup_html = f"""
            <div style='font-family:sans-serif;font-size:12px;min-width:200px;border-left:4px solid red;padding-left:8px'>
              <b style='color:red'>⚠️ CONFLITO DE LIVRO</b><br>
              <b>UC:</b> {row['uc']}<br>
              <b>Base:</b> {row['base']}<br>
              <b>Livro Informado:</b> <span style='color:red'>{row['livro']}</span><br>
              <b>Livro Correto:</b> <span style='color:green'>{c['livro_correto']}</span><br>
              <b>Área:</b> {c['area']}<br>
              <b>Endereço:</b> {row['endereco']}<br>
              <b>Lat/Lon:</b> {row['latitude']:.6f}, {row['longitude']:.6f}
            </div>"""
            folium.CircleMarker(
                location=[row['latitude'], row['longitude']],
                radius=9, color='red', weight=3,
                fill=True, fill_color='#ff4444', fill_opacity=0.75,
                tooltip=f"⚠️ {row['base']}: {row['uc']} | Livro {row['livro']} → Correto: {c['livro_correto']}",
                popup=folium.Popup(popup_html, max_width=240)
            ).add_to(grp_conflitos)
        else:
            popup_html = f"""
            <div style='font-family:sans-serif;font-size:12px;min-width:180px'>
              <b>UC:</b> {row['uc']}<br>
              <b>Base:</b> {row['base']}<br>
              <b>Livro:</b> {row['livro']}<br>
              <b>Endereço:</b> {row['endereco']}<br>
              <b>Lat/Lon:</b> {row['latitude']:.6f}, {row['longitude']:.6f}
            </div>"""
            folium.CircleMarker(
                location=[row['latitude'], row['longitude']],
                radius=6, color='#333', weight=1,
                fill=True, fill_color=cor, fill_opacity=0.75,
                tooltip=f"✅ {row['base']}: {row['uc']} | Livro {row['livro']}",
                popup=folium.Popup(popup_html, max_width=220)
            ).add_to(grp_comp_ok)

    # Adiciona grupos ao mapa
    grp_areas.add_to(mapa)
    grp_livros.add_to(mapa)
    grp_bd.add_to(mapa)
    grp_comp_ok.add_to(mapa)
    grp_conflitos.add_to(mapa)
    folium.LayerControl(collapsed=False).add_to(mapa)

    # --- Painel lateral (estatísticas + filtro por polo) ---
    polo_list = sorted(df_bd['polo'].dropna().unique().tolist())
    total_ucs = len(df_bd)
    total_conf = len(conflitos)
    total_comp = len(df_comp)

    # Dados de conflitos para o painel
    conflitos_json = json.dumps([{
        'uc': c['uc'],
        'base': c['base'],
        'livro_inf': c['livro_informado'],
        'livro_cor': c['livro_correto'],
        'area': c['area'],
        'lat': c['latitude'],
        'lon': c['longitude'],
        'endereco': c['endereco']
    } for c in conflitos])

    painel_html = f"""
    <style>
      #painel-lateral {{
        position: fixed;
        top: 10px;
        right: 10px;
        z-index: 1001;
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.18);
        width: 280px;
        font-family: 'Segoe UI', sans-serif;
        font-size: 13px;
        overflow: hidden;
        border: 1px solid #ddd;
      }}
      #painel-header {{
        background: #1a6fc4;
        color: white;
        padding: 10px 14px;
        font-weight: bold;
        font-size: 14px;
        cursor: pointer;
        user-select: none;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }}
      #painel-corpo {{
        padding: 12px;
      }}
      .stat-box {{
        display: flex;
        justify-content: space-between;
        padding: 5px 0;
        border-bottom: 1px solid #f0f0f0;
      }}
      .stat-val {{
        font-weight: bold;
        color: #1a6fc4;
      }}
      .stat-val.vermelho {{ color: #e53935; }}
      select, input[type=text] {{
        width: 100%;
        padding: 5px;
        margin-top: 5px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 12px;
        box-sizing: border-box;
      }}
      #lista-conflitos {{
        max-height: 200px;
        overflow-y: auto;
        margin-top: 8px;
        font-size: 11px;
      }}
      .conf-item {{
        background: #fff5f5;
        border-left: 3px solid red;
        padding: 5px 8px;
        margin-bottom: 4px;
        border-radius: 3px;
        cursor: pointer;
      }}
      .conf-item:hover {{ background: #ffe0e0; }}
      .secao-titulo {{
        font-weight: bold;
        color: #555;
        margin: 10px 0 4px 0;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }}
      #btn-exportar {{
        width: 100%;
        padding: 7px;
        background: #1a6fc4;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 12px;
        margin-top: 8px;
      }}
      #btn-exportar:hover {{ background: #155da0; }}
      #busca-uc {{ margin-top: 6px; }}
    </style>

    <div id="painel-lateral">
      <div id="painel-header" onclick="togglePainel()">
        🗺️ Painel de Controle <span id="seta-painel">▼</span>
      </div>
      <div id="painel-corpo">

        <div class="secao-titulo">📊 Estatísticas</div>
        <div class="stat-box"><span>UCs BD_CBA</span><span class="stat-val">{total_ucs:,}</span></div>
        <div class="stat-box"><span>UCs Comparação</span><span class="stat-val">{total_comp:,}</span></div>
        <div class="stat-box"><span>Conflitos detectados</span>
          <span class="stat-val {'vermelho' if total_conf > 0 else ''}">{total_conf}</span>
        </div>
        <div class="stat-box"><span>Polos</span><span class="stat-val">{len(polo_list)}</span></div>

        <div class="secao-titulo">🔍 Filtros</div>
        <label>Polo:</label>
        <select id="polo-select" onchange="filtrarPolo(this.value)">
          <option value="">Todos os Polos</option>
          {''.join(f'<option value="{p}">{p}</option>' for p in polo_list)}
        </select>

        <label style="margin-top:8px;display:block">Buscar UC:</label>
        <input type="text" id="busca-uc" placeholder="Digite número da UC..." oninput="buscarUC(this.value)">
        <div id="resultado-busca" style="font-size:11px;color:#555;margin-top:4px;"></div>

        {_render_conflitos_html(conflitos, total_conf)}

      </div>
    </div>

    <script>
    var painelAberto = true;
    function togglePainel() {{
      var corpo = document.getElementById('painel-corpo');
      var seta  = document.getElementById('seta-painel');
      if (painelAberto) {{
        corpo.style.display = 'none';
        seta.textContent = '▶';
      }} else {{
        corpo.style.display = 'block';
        seta.textContent = '▼';
      }}
      painelAberto = !painelAberto;
    }}

    function getMap() {{
      var els = document.getElementsByClassName('folium-map');
      if (els.length > 0) return els[0]._leaflet_map || window._leaflet_map;
      return null;
    }}

    function irParaConflito(lat, lon) {{
      var mapa = getMap() || findLeafletMap();
      if (mapa) mapa.setView([lat, lon], 16);
    }}

    function findLeafletMap() {{
      for (var key in window) {{
        if (window[key] && window[key]._leaflet_id) return window[key];
      }}
      return null;
    }}

    function buscarUC(termo) {{
      var res = document.getElementById('resultado-busca');
      if (!termo || termo.length < 3) {{ res.textContent = ''; return; }}
      // Percorre markers no mapa
      var mapa = findLeafletMap();
      var encontrados = 0;
      if (mapa) {{
        mapa.eachLayer(function(layer) {{
          if (layer.getTooltip) {{
            var tip = layer.getTooltip();
            if (tip && tip._content && tip._content.toString().includes(termo)) {{
              encontrados++;
              if (encontrados === 1) mapa.setView(layer.getLatLng(), 17);
            }}
          }}
        }});
      }}
      res.textContent = encontrados > 0 ? encontrados + ' UC(s) encontrada(s)' : 'Não encontrado';
    }}

    function filtrarPolo(polo) {{
      // Recarrega a página com filtro visual via opacity nas camadas
      // (implementação via estilos, pois folium não expõe propriedades facilmente)
      console.log('Filtrar polo:', polo);
    }}
    </script>
    """

    mapa.get_root().html.add_child(folium.Element(painel_html))
    return mapa


# =============================================================================
# PROCESSAMENTO PRINCIPAL
# =============================================================================

def processar(progress_var, status_label, log_text, params):
    def atualizar(pct, msg):
        progress_var.set(pct)
        status_label.config(text=msg)
        log_text.insert('end', f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")
        log_text.see('end')
        log.info(msg)

    try:
        atualizar(5, "Carregando BD_CBA...")

        # 1. BD_CBA
        df_bd = pd.read_excel(params['caminho_principal'], sheet_name=params['aba_bd'])
        df_bd = df_bd[[params['col_uc_bd'], params['col_lat_bd'], params['col_lon_bd'],
                       params['col_end_bd'], params['col_roteiro']]].copy()
        df_bd.columns = ['uc', 'latitude', 'longitude', 'endereco', 'roteiro']
        df_bd['latitude']  = df_bd['latitude'].apply(converter_coord)
        df_bd['longitude'] = df_bd['longitude'].apply(converter_coord)
        df_bd.dropna(subset=['latitude', 'longitude'], inplace=True)
        df_bd = df_bd[df_bd['latitude'].between(-90, 90) & df_bd['longitude'].between(-180, 180)]
        df_bd[['livro', 'area']] = df_bd['roteiro'].apply(lambda x: pd.Series(extrair_livro_area(x)))
        df_bd = df_bd[df_bd['livro'] > 0].copy()
        df_bd['base'] = 'BD_CBA'
        atualizar(15, f"BD_CBA: {len(df_bd):,} UCs válidas carregadas.")

        # 2. Segmentação
        atualizar(20, "Carregando segmentação...")
        df_seg = pd.read_excel(params['caminho_seg'], sheet_name=params['aba_seg'])
        df_seg = df_seg.rename(columns={
            params['col_cod_area']:  'cod_area',
            params['col_nome_area']: 'nome_area',
            params['col_polo']:      'polo'
        })
        df_seg['cod_area'] = pd.to_numeric(df_seg['cod_area'], errors='coerce').fillna(0).astype(int)
        df_bd = df_bd.merge(df_seg[['cod_area', 'polo', 'nome_area']],
                            left_on='area', right_on='cod_area', how='left')
        df_bd.dropna(subset=['polo'], inplace=True)
        if df_bd.empty:
            messagebox.showerror("Erro", "Nenhuma UC com polo associado. Verifique o mapeamento.")
            return
        atualizar(25, f"Segmentação: {df_bd['polo'].nunique()} polos encontrados.")

        # 3. Bases de comparação
        df_comp = pd.DataFrame()
        for flag, aba, cols_map, base_nome in [
            (params.get('incluir_fora'), 'FORA_ROTA',
             ['col_uc_fora','col_lat_fora','col_lon_fora','col_end_fora','col_livro_fora'],
             'FORA_ROTA'),
            (params.get('incluir_lig'), 'LIGACOES_NOVAS',
             ['col_uc_lig','col_lat_lig','col_lon_lig','col_end_lig','col_livro_lig'],
             'LIGACOES_NOVAS'),
        ]:
            if not flag:
                continue
            atualizar(30, f"Carregando {base_nome}...")
            try:
                df_tmp = pd.read_excel(params['caminho_principal'], sheet_name=aba)
                df_tmp = df_tmp[[params[c] for c in cols_map]].copy()
                df_tmp.columns = ['uc', 'latitude', 'longitude', 'endereco', 'livro']
                df_tmp['latitude']  = df_tmp['latitude'].apply(converter_coord)
                df_tmp['longitude'] = df_tmp['longitude'].apply(converter_coord)
                df_tmp.dropna(subset=['latitude', 'longitude'], inplace=True)
                df_tmp['livro'] = pd.to_numeric(df_tmp['livro'], errors='coerce').fillna(0).astype(int)
                df_tmp['base'] = base_nome
                df_comp = pd.concat([df_comp, df_tmp], ignore_index=True)
                atualizar(35, f"{base_nome}: {len(df_tmp):,} registros.")
            except Exception as e:
                atualizar(35, f"Aviso: erro ao carregar {base_nome}: {e}")

        # 4. Gerar polígonos (processamento em paralelo por polo)
        atualizar(40, "Gerando polígonos por polo...")
        polos = df_bd['polo'].unique()
        todos_poligonos_area  = []
        todos_poligonos_livro = []
        eps         = params['eps']
        min_samples = params['min_samples']

        for i, polo in enumerate(polos):
            pct = 40 + int(35 * i / len(polos))
            atualizar(pct, f"Polo {polo} ({i+1}/{len(polos)}) — gerando polígonos...")
            df_polo = df_bd[df_bd['polo'] == polo]

            # Por área
            for p in gerar_poligonos(df_polo, ['area'], eps, min_samples):
                area_id  = p['grupo'][0]
                nome_arr = df_seg[df_seg['cod_area'] == area_id]['nome_area'].values
                todos_poligonos_area.append({
                    'polo': polo, 'area_id': area_id,
                    'nome_area': nome_arr[0] if len(nome_arr) else f"Área {area_id}",
                    'coords': p['coords'], 'centro': p['centro']
                })

            # Por livro + área
            for p in gerar_poligonos(df_polo, ['livro', 'area'], eps, min_samples):
                livro   = p['grupo'][0]
                area_id = p['grupo'][1]
                todos_poligonos_livro.append({
                    'polo': polo, 'livro': livro, 'area_id': area_id,
                    'coords': p['coords'], 'centro': p['centro']
                })

        atualizar(76, f"Polígonos: {len(todos_poligonos_area)} áreas, {len(todos_poligonos_livro)} livros.")

        # 5. Verificar conflitos
        atualizar(80, "Verificando conflitos de livro...")
        conflitos = []
        if not df_comp.empty:
            for polo in polos:
                pol_livro_polo = [p for p in todos_poligonos_livro if p['polo'] == polo]
                if pol_livro_polo:
                    conflitos.extend(verificar_conflitos(df_comp, pol_livro_polo))
        atualizar(85, f"Conflitos detectados: {len(conflitos)}")

        # 6. Construir mapa
        atualizar(88, "Construindo mapa interativo...")
        mapa = construir_mapa(df_bd, df_comp, todos_poligonos_area, todos_poligonos_livro,
                               conflitos, df_seg, params)
        mapa.save(params['saida'])
        atualizar(95, "Mapa salvo. Gerando relatório Excel...")

        # 7. Exportar relatório
        xlsx = exportar_relatorio(conflitos, df_bd, params['saida'])

        atualizar(100, "✅ Concluído!")
        msg = f"Mapa gerado:\n{params['saida']}"
        if xlsx:
            msg += f"\n\nRelatório Excel:\n{xlsx}"
        if conflitos:
            msg += f"\n\n⚠️ {len(conflitos)} conflito(s) de livro detectado(s)."
        messagebox.showinfo("Sucesso", msg)

    except Exception as e:
        log.exception("Erro durante processamento")
        messagebox.showerror("Erro", f"Ocorreu um erro:\n{str(e)}")
        status_label.config(text="❌ Erro na execução")
        progress_var.set(0)


# =============================================================================
# INTERFACE GRÁFICA
# =============================================================================

class Aplicacao:
    def __init__(self, root):
        self.root = root
        root.title("Gerador de Mapa UC — Conferência de Coordenadas e Livros")
        root.geometry("960x820")
        root.resizable(True, True)

        # Configuração visual
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TNotebook.Tab', padding=[12, 6], font=('Segoe UI', 10))
        style.configure('TButton', font=('Segoe UI', 10))
        style.configure('TLabel', font=('Segoe UI', 10))
        style.configure('Header.TLabel', font=('Segoe UI', 11, 'bold'), foreground='#1a6fc4')

        # Variáveis de arquivo
        self.caminho_principal = tk.StringVar()
        self.caminho_seg       = tk.StringVar()
        self.aba_bd            = tk.StringVar()
        self.aba_seg           = tk.StringVar()

        # Colunas detectadas
        self.colunas_bd   = []
        self.colunas_seg  = []
        self.colunas_fora = []
        self.colunas_lig  = []

        # Mapeamentos BD_CBA
        self.col_uc_bd   = tk.StringVar()
        self.col_lat_bd  = tk.StringVar()
        self.col_lon_bd  = tk.StringVar()
        self.col_end_bd  = tk.StringVar()
        self.col_roteiro = tk.StringVar()

        # Mapeamentos segmentação
        self.col_cod_area  = tk.StringVar()
        self.col_nome_area = tk.StringVar()
        self.col_polo      = tk.StringVar()

        # Mapeamentos FORA_ROTA
        self.incluir_fora  = tk.BooleanVar(value=True)
        self.col_uc_fora   = tk.StringVar()
        self.col_lat_fora  = tk.StringVar()
        self.col_lon_fora  = tk.StringVar()
        self.col_end_fora  = tk.StringVar()
        self.col_livro_fora= tk.StringVar()

        # Mapeamentos LIGACOES_NOVAS
        self.incluir_lig   = tk.BooleanVar(value=True)
        self.col_uc_lig    = tk.StringVar()
        self.col_lat_lig   = tk.StringVar()
        self.col_lon_lig   = tk.StringVar()
        self.col_end_lig   = tk.StringVar()
        self.col_livro_lig = tk.StringVar()

        # Params DBSCAN
        self.eps         = tk.DoubleVar(value=EPS_DEFAULT)
        self.min_samples = tk.IntVar(value=MIN_SAMPLES_DEFAULT)
        self.saida       = tk.StringVar(value="mapa_uc_conferencia.html")

        self._criar_widgets()

    # -------------------------------------------------------------------------
    # WIDGETS
    # -------------------------------------------------------------------------

    def _criar_widgets(self):
        # Cabeçalho
        header = tk.Frame(self.root, bg='#1a6fc4', height=50)
        header.pack(fill='x')
        tk.Label(header, text="🗺️  Conferência de UCs — Coordenadas e Livros",
                 bg='#1a6fc4', fg='white',
                 font=('Segoe UI', 13, 'bold')).pack(side='left', padx=15, pady=10)

        nb = ttk.Notebook(self.root)
        nb.pack(fill='both', expand=True, padx=5, pady=5)

        self.aba1 = ttk.Frame(nb); nb.add(self.aba1, text="  📁 Arquivos  ")
        self.aba2 = ttk.Frame(nb); nb.add(self.aba2, text="  🗃️ BD_CBA  ")
        self.aba3 = ttk.Frame(nb); nb.add(self.aba3, text="  🗂️ Segmentação  ")
        self.aba4 = ttk.Frame(nb); nb.add(self.aba4, text="  🔄 Comparação  ")
        self.aba5 = ttk.Frame(nb); nb.add(self.aba5, text="  ▶ Gerar Mapa  ")

        self._criar_aba_arquivos(self.aba1)
        self._criar_aba_bd()
        self._criar_aba_seg()
        self._criar_aba_comparacao()
        self._criar_aba_execucao(self.aba5)

    def _label_secao(self, parent, texto):
        ttk.Label(parent, text=texto, style='Header.TLabel').pack(anchor='w', pady=(8, 2))

    def _criar_aba_arquivos(self, parent):
        canvas = tk.Canvas(parent, borderwidth=0)
        vsb = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        frame = ttk.Frame(canvas)
        canvas.create_window((0, 0), window=frame, anchor='nw')
        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        pad = {'padx': 10, 'pady': 4}

        self._label_secao(frame, "📂 Arquivo Principal (BD_CBA / FORA_ROTA / LIGACOES_NOVAS)")
        f1 = ttk.Frame(frame); f1.pack(fill='x', **pad)
        ttk.Entry(f1, textvariable=self.caminho_principal, width=60).pack(side='left', expand=True, fill='x')
        ttk.Button(f1, text="Procurar", command=self._sel_principal, width=10).pack(side='left', padx=4)
        ttk.Button(f1, text="✔ Carregar", command=self._carregar_principal, width=12).pack(side='left')

        ttk.Label(frame, text="Aba BD_CBA:").pack(anchor='w', padx=10)
        f2 = ttk.Frame(frame); f2.pack(fill='x', **pad)
        self.combo_aba_bd = ttk.Combobox(f2, textvariable=self.aba_bd, width=40)
        self.combo_aba_bd.pack(side='left')
        self.combo_aba_bd.bind('<<ComboboxSelected>>', self._atualizar_cols_bd)

        ttk.Separator(frame, orient='horizontal').pack(fill='x', padx=10, pady=8)

        self._label_secao(frame, "📂 Arquivo de Segmentação")
        f3 = ttk.Frame(frame); f3.pack(fill='x', **pad)
        ttk.Entry(f3, textvariable=self.caminho_seg, width=60).pack(side='left', expand=True, fill='x')
        ttk.Button(f3, text="Procurar", command=self._sel_seg, width=10).pack(side='left', padx=4)
        ttk.Button(f3, text="✔ Carregar", command=self._carregar_seg, width=12).pack(side='left')

        ttk.Label(frame, text="Aba Segmentação:").pack(anchor='w', padx=10)
        f4 = ttk.Frame(frame); f4.pack(fill='x', **pad)
        self.combo_aba_seg = ttk.Combobox(f4, textvariable=self.aba_seg, width=40)
        self.combo_aba_seg.pack(side='left')
        self.combo_aba_seg.bind('<<ComboboxSelected>>', self._atualizar_cols_seg)

        ttk.Separator(frame, orient='horizontal').pack(fill='x', padx=10, pady=8)

        self._label_secao(frame, "💾 Arquivo de Saída (HTML)")
        f5 = ttk.Frame(frame); f5.pack(fill='x', **pad)
        ttk.Entry(f5, textvariable=self.saida, width=60).pack(side='left', expand=True, fill='x')
        ttk.Button(f5, text="Salvar como...", command=self._sel_saida).pack(side='left', padx=4)

    def _criar_aba_bd(self):
        for w in self.aba2.winfo_children(): w.destroy()
        frame = ttk.Frame(self.aba2, padding=15)
        frame.pack(fill='both', expand=True)
        self._label_secao(frame, "Mapeamento de Colunas — BD_CBA")
        ttk.Label(frame, text="Selecione qual coluna do arquivo corresponde a cada campo:",
                  foreground='gray').pack(anchor='w', pady=(0, 8))
        self._combo(frame, "UC (código do consumidor):", self.col_uc_bd, self.colunas_bd)
        self._combo(frame, "Latitude:", self.col_lat_bd, self.colunas_bd)
        self._combo(frame, "Longitude:", self.col_lon_bd, self.colunas_bd)
        self._combo(frame, "Endereço / Bairro:", self.col_end_bd, self.colunas_bd)
        self._combo(frame, "Roteiro (livro/area/rota):", self.col_roteiro, self.colunas_bd)
        ttk.Button(frame, text="🤖 Sugerir Mapeamento Automático",
                   command=self._sugerir_bd).pack(pady=12)

    def _criar_aba_seg(self):
        for w in self.aba3.winfo_children(): w.destroy()
        frame = ttk.Frame(self.aba3, padding=15)
        frame.pack(fill='both', expand=True)
        self._label_secao(frame, "Mapeamento de Colunas — Segmentação")
        self._combo(frame, "Código da Área:", self.col_cod_area, self.colunas_seg)
        self._combo(frame, "Nome da Área:", self.col_nome_area, self.colunas_seg)
        self._combo(frame, "Polo:", self.col_polo, self.colunas_seg)
        ttk.Button(frame, text="🤖 Sugerir Mapeamento Automático",
                   command=self._sugerir_seg).pack(pady=12)

    def _criar_aba_comparacao(self):
        for w in self.aba4.winfo_children(): w.destroy()
        canvas = tk.Canvas(self.aba4, borderwidth=0)
        vsb = ttk.Scrollbar(self.aba4, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        frame = ttk.Frame(canvas, padding=15)
        canvas.create_window((0, 0), window=frame, anchor='nw')
        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        # FORA_ROTA
        cb_fora = ttk.Checkbutton(frame, text="✅ Incluir FORA_ROTA",
                                  variable=self.incluir_fora,
                                  command=lambda: self._toggle_frame(self.frame_fora, self.incluir_fora))
        cb_fora.pack(anchor='w')
        self.frame_fora = ttk.LabelFrame(frame, text="FORA_ROTA — Mapeamento", padding=8)
        self.frame_fora.pack(fill='x', pady=5)
        self._criar_campos_comp(self.frame_fora, 'fora',
                                self.col_uc_fora, self.col_lat_fora, self.col_lon_fora,
                                self.col_end_fora, self.col_livro_fora, self.colunas_fora)

        ttk.Separator(frame, orient='horizontal').pack(fill='x', pady=10)

        # LIGACOES_NOVAS
        cb_lig = ttk.Checkbutton(frame, text="✅ Incluir LIGACOES_NOVAS",
                                 variable=self.incluir_lig,
                                 command=lambda: self._toggle_frame(self.frame_lig, self.incluir_lig))
        cb_lig.pack(anchor='w')
        self.frame_lig = ttk.LabelFrame(frame, text="LIGACOES_NOVAS — Mapeamento", padding=8)
        self.frame_lig.pack(fill='x', pady=5)
        self._criar_campos_comp(self.frame_lig, 'lig',
                                self.col_uc_lig, self.col_lat_lig, self.col_lon_lig,
                                self.col_end_lig, self.col_livro_lig, self.colunas_lig)

    def _criar_campos_comp(self, parent, sufixo, var_uc, var_lat, var_lon, var_end, var_livro, colunas):
        self._combo(parent, "UC:", var_uc, colunas)
        self._combo(parent, "Latitude:", var_lat, colunas)
        self._combo(parent, "Longitude:", var_lon, colunas)
        self._combo(parent, "Endereço:", var_end, colunas)
        self._combo(parent, "Livro:", var_livro, colunas)
        ttk.Button(parent, text="🤖 Sugerir Automático",
                   command=lambda: self._sugerir_comp(sufixo, var_uc, var_lat, var_lon, var_end, var_livro)
                   ).pack(pady=5)

    def _criar_aba_execucao(self, parent):
        frame = ttk.Frame(parent, padding=15)
        frame.pack(fill='both', expand=True)

        self._label_secao(frame, "⚙️ Parâmetros DBSCAN")
        pf = ttk.Frame(frame); pf.pack(fill='x', pady=4)
        ttk.Label(pf, text="EPS (raio em graus):").pack(side='left')
        ttk.Entry(pf, textvariable=self.eps, width=10).pack(side='left', padx=8)
        ttk.Label(pf, text="(padrão 0.008 ≈ ~900m)", foreground='gray').pack(side='left')

        pf2 = ttk.Frame(frame); pf2.pack(fill='x', pady=4)
        ttk.Label(pf2, text="Mínimo de pontos por cluster:").pack(side='left')
        ttk.Entry(pf2, textvariable=self.min_samples, width=10).pack(side='left', padx=8)

        ttk.Separator(frame, orient='horizontal').pack(fill='x', pady=10)

        self._label_secao(frame, "📊 Log de Execução")
        log_frame = ttk.Frame(frame)
        log_frame.pack(fill='both', expand=True, pady=4)
        self.log_text = tk.Text(log_frame, height=8, font=('Consolas', 9), state='normal',
                                bg='#1e1e1e', fg='#d4d4d4', insertbackground='white')
        log_sb = ttk.Scrollbar(log_frame, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_sb.set)
        log_sb.pack(side='right', fill='y')
        self.log_text.pack(fill='both', expand=True)

        self.progress_var = tk.IntVar(value=0)
        self.progress = ttk.Progressbar(frame, orient='horizontal', length=500,
                                         mode='determinate', variable=self.progress_var)
        self.progress.pack(pady=10, fill='x')

        self.status_label = ttk.Label(frame, text="Aguardando...", foreground='gray')
        self.status_label.pack()

        self.btn_executar = ttk.Button(frame, text="▶  GERAR MAPA",
                                       command=self._executar, width=25)
        self.btn_executar.pack(pady=10)

    # -------------------------------------------------------------------------
    # HELPERS DE WIDGET
    # -------------------------------------------------------------------------

    def _combo(self, parent, label, variable, values_list):
        f = ttk.Frame(parent)
        f.pack(anchor='w', pady=3, fill='x')
        ttk.Label(f, text=label, width=28).pack(side='left')
        cb = ttk.Combobox(f, textvariable=variable, values=values_list, width=38)
        cb.pack(side='left', padx=5)
        return cb

    def _toggle_frame(self, frame, var):
        if var.get():
            frame.pack(fill='x', pady=5)
        else:
            frame.pack_forget()

    # -------------------------------------------------------------------------
    # SELEÇÃO DE ARQUIVOS
    # -------------------------------------------------------------------------

    def _sel_principal(self):
        p = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx *.xls")])
        if p: self.caminho_principal.set(p)

    def _sel_seg(self):
        p = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx *.xls")])
        if p: self.caminho_seg.set(p)

    def _sel_saida(self):
        p = filedialog.asksaveasfilename(defaultextension=".html",
                                          filetypes=[("HTML", "*.html")])
        if p: self.saida.set(p)

    # -------------------------------------------------------------------------
    # CARREGAMENTO DE ABAS / COLUNAS
    # -------------------------------------------------------------------------

    def _carregar_principal(self):
        if not self.caminho_principal.get():
            messagebox.showwarning("Aviso", "Selecione o arquivo principal primeiro.")
            return
        try:
            xl = pd.ExcelFile(self.caminho_principal.get())
            self.combo_aba_bd['values'] = xl.sheet_names
            self.aba_bd.set('BD_CBA' if 'BD_CBA' in xl.sheet_names else xl.sheet_names[0])
            self._atualizar_cols_bd()
            self._atualizar_cols_comparacao()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def _carregar_seg(self):
        if not self.caminho_seg.get():
            messagebox.showwarning("Aviso", "Selecione o arquivo de segmentação.")
            return
        try:
            xl = pd.ExcelFile(self.caminho_seg.get())
            self.combo_aba_seg['values'] = xl.sheet_names
            self.aba_seg.set(xl.sheet_names[0])
            self._atualizar_cols_seg()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def _atualizar_cols_bd(self, event=None):
        if not self.caminho_principal.get() or not self.aba_bd.get(): return
        try:
            df = pd.read_excel(self.caminho_principal.get(), sheet_name=self.aba_bd.get(), nrows=1)
            self.colunas_bd = list(df.columns)
            self._criar_aba_bd()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def _atualizar_cols_seg(self, event=None):
        if not self.caminho_seg.get() or not self.aba_seg.get(): return
        try:
            df = pd.read_excel(self.caminho_seg.get(), sheet_name=self.aba_seg.get(), nrows=1)
            self.colunas_seg = list(df.columns)
            self._criar_aba_seg()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def _atualizar_cols_comparacao(self):
        if not self.caminho_principal.get(): return
        try:
            xl = pd.ExcelFile(self.caminho_principal.get())
            for aba, attr in [('FORA_ROTA', 'colunas_fora'), ('LIGACOES_NOVAS', 'colunas_lig')]:
                if aba in xl.sheet_names:
                    df = pd.read_excel(self.caminho_principal.get(), sheet_name=aba, nrows=1)
                    setattr(self, attr, list(df.columns))
                else:
                    setattr(self, attr, [])
            self._criar_aba_comparacao()
        except Exception as e:
            messagebox.showerror("Erro", str(e))

    # -------------------------------------------------------------------------
    # SUGESTÃO AUTOMÁTICA DE COLUNAS
    # -------------------------------------------------------------------------

    def _sugerir_bd(self):
        m = {
            self.col_uc_bd:   ['NUMCDC_ITC','NUMCDC','UC','CONSUMIDOR'],
            self.col_lat_bd:  ['VRLIT_PTO_ETG_CVR','LATITUDE','LAT'],
            self.col_lon_bd:  ['VLRLGT_PTO_ETG_CVR','LONGITUDE','LON'],
            self.col_end_bd:  ['BAIRRO','ENDERECO','END'],
            self.col_roteiro: ['ROTEIRO'],
        }
        self._aplicar_sugestoes(m, self.colunas_bd, "BD_CBA")

    def _sugerir_seg(self):
        m = {
            self.col_cod_area:  ['COD LOCALIDADE','CODIGO LOCALIDADE','COD_AREA','CODIGO'],
            self.col_nome_area: ['LOCALIDADE','NOME_AREA','NOME'],
            self.col_polo:      ['POLO'],
        }
        self._aplicar_sugestoes(m, self.colunas_seg, "Segmentação")

    def _sugerir_comp(self, sufixo, var_uc, var_lat, var_lon, var_end, var_livro):
        colunas = self.colunas_fora if sufixo == 'fora' else self.colunas_lig
        nome    = 'FORA_ROTA'       if sufixo == 'fora' else 'LIGACOES_NOVAS'
        m = {
            var_uc:    ['NUMCDC','UC','NUMCDC_ITC'],
            var_lat:   ['VRLIT_PTO_ETG_CVR','LATITUDE','LAT'],
            var_lon:   ['VLRLGT_PTO_ETG_CVR','LONGITUDE','LON'],
            var_end:   ['BAIRRO','ENDERECO','END'],
            var_livro: ['NUMLIV','LIVRO'],
        }
        self._aplicar_sugestoes(m, colunas, nome)

    def _aplicar_sugestoes(self, mapa_vars, colunas, nome_aba):
        if not colunas:
            messagebox.showwarning("Aviso", f"Carregue o arquivo de {nome_aba} primeiro.")
            return
        acertos = 0
        for var, candidatos in mapa_vars.items():
            col = _auto_map(colunas, candidatos)
            if col:
                var.set(col)
                acertos += 1
        messagebox.showinfo("Sugestão",
                            f"{nome_aba}: {acertos}/{len(mapa_vars)} colunas identificadas automaticamente.\n"
                            "Verifique e ajuste se necessário.")

    # -------------------------------------------------------------------------
    # EXECUÇÃO
    # -------------------------------------------------------------------------

    def _validar(self):
        erros = []
        if not self.caminho_principal.get(): erros.append("Arquivo principal não selecionado.")
        if not self.aba_bd.get():            erros.append("Aba BD_CBA não selecionada.")
        for var, nome in [(self.col_uc_bd,'UC BD'), (self.col_lat_bd,'Latitude BD'),
                          (self.col_lon_bd,'Longitude BD'), (self.col_end_bd,'Endereço BD'),
                          (self.col_roteiro,'Roteiro BD')]:
            if not var.get(): erros.append(f"Coluna '{nome}' não mapeada.")
        if not self.caminho_seg.get():   erros.append("Arquivo de segmentação não selecionado.")
        if not self.aba_seg.get():       erros.append("Aba de segmentação não selecionada.")
        for var, nome in [(self.col_cod_area,'Código Área'), (self.col_nome_area,'Nome Área'),
                          (self.col_polo,'Polo')]:
            if not var.get(): erros.append(f"Coluna '{nome}' não mapeada.")
        if self.incluir_fora.get():
            for var, nome in [(self.col_uc_fora,'UC FORA'), (self.col_lat_fora,'Lat FORA'),
                              (self.col_lon_fora,'Lon FORA'), (self.col_end_fora,'End FORA'),
                              (self.col_livro_fora,'Livro FORA')]:
                if not var.get(): erros.append(f"Coluna '{nome}' não mapeada.")
        if self.incluir_lig.get():
            for var, nome in [(self.col_uc_lig,'UC LIG'), (self.col_lat_lig,'Lat LIG'),
                              (self.col_lon_lig,'Lon LIG'), (self.col_end_lig,'End LIG'),
                              (self.col_livro_lig,'Livro LIG')]:
                if not var.get(): erros.append(f"Coluna '{nome}' não mapeada.")
        return erros

    def _executar(self):
        erros = self._validar()
        if erros:
            messagebox.showerror("Campos obrigatórios", "\n".join(f"• {e}" for e in erros))
            return

        params = {
            'caminho_principal': self.caminho_principal.get(),
            'aba_bd':            self.aba_bd.get(),
            'col_uc_bd':         self.col_uc_bd.get(),
            'col_lat_bd':        self.col_lat_bd.get(),
            'col_lon_bd':        self.col_lon_bd.get(),
            'col_end_bd':        self.col_end_bd.get(),
            'col_roteiro':       self.col_roteiro.get(),
            'caminho_seg':       self.caminho_seg.get(),
            'aba_seg':           self.aba_seg.get(),
            'col_cod_area':      self.col_cod_area.get(),
            'col_nome_area':     self.col_nome_area.get(),
            'col_polo':          self.col_polo.get(),
            'incluir_fora':      self.incluir_fora.get(),
            'incluir_lig':       self.incluir_lig.get(),
            'eps':               self.eps.get(),
            'min_samples':       self.min_samples.get(),
            'saida':             self.saida.get(),
        }
        if self.incluir_fora.get():
            params.update({'col_uc_fora': self.col_uc_fora.get(), 'col_lat_fora': self.col_lat_fora.get(),
                           'col_lon_fora': self.col_lon_fora.get(), 'col_end_fora': self.col_end_fora.get(),
                           'col_livro_fora': self.col_livro_fora.get()})
        if self.incluir_lig.get():
            params.update({'col_uc_lig': self.col_uc_lig.get(), 'col_lat_lig': self.col_lat_lig.get(),
                           'col_lon_lig': self.col_lon_lig.get(), 'col_end_lig': self.col_end_lig.get(),
                           'col_livro_lig': self.col_livro_lig.get()})

        self.btn_executar.config(state='disabled', text="⏳ Processando...")
        self.progress_var.set(0)
        self.log_text.delete('1.0', 'end')

        def ao_terminar():
            thread = threading.Thread(
                target=processar,
                args=(self.progress_var, self.status_label, self.log_text, params),
                daemon=True
            )
            thread.start()
            def checar():
                if thread.is_alive():
                    self.root.after(150, checar)
                else:
                    self.btn_executar.config(state='normal', text="▶  GERAR MAPA")
            self.root.after(150, checar)

        ao_terminar()


# =============================================================================
# ENTRY POINT
# =============================================================================
if __name__ == "__main__":
    root = tk.Tk()
    app = Aplicacao(root)
    root.mainloop()