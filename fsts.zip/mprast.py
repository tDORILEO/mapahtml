import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading
import pandas as pd
import numpy as np
import folium
from sklearn.cluster import DBSCAN
from scipy.spatial import ConvexHull
from shapely.geometry import Point, Polygon
from shapely.strtree import STRtree
import warnings
warnings.filterwarnings('ignore')

# =============================================================================
# CONFIGURAÇÕES GLOBAIS
# =============================================================================
EPS_DEFAULT = 0.008
MIN_SAMPLES_DEFAULT = 3

COR_POR_LIVRO = {}
paleta_urb = ["#1f77b4","#2ca02c","#17becf","#1f77b4","#2ca02c","#17becf",
              "#1f77b4","#2ca02c","#17becf","#1f77b4","#2ca02c","#17becf",
              "#1f77b4","#2ca02c","#17becf","#1f77b4","#2ca02c","#17becf","#1f77b4"]
for i, livro in enumerate(range(1,20)):
    COR_POR_LIVRO[livro] = paleta_urb[i % len(paleta_urb)]
paleta_rur = ["#ff7f0e","#d62728","#e377c2","#8c564b","#ff7f0e","#d62728",
              "#e377c2","#8c564b","#ff7f0e","#d62728","#e377c2","#8c564b",
              "#ff7f0e","#d62728","#e377c2","#8c564b","#ff7f0e"]
for i, livro in enumerate(range(41,58)):
    COR_POR_LIVRO[livro] = paleta_rur[i % len(paleta_rur)]

# =============================================================================
# FUNÇÕES DE PROCESSAMENTO
# =============================================================================
def converter_coord(val):
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        val = val.replace(',', '.')
        try:
            return float(val)
        except:
            return np.nan
    return np.nan

def extrair_livro_area(roteiro):
    if not isinstance(roteiro, str):
        return (0,0)
    partes = roteiro.split('/')
    if len(partes) >= 2:
        try:
            livro = int(partes[0])
            area = int(partes[1])
            return (livro, area)
        except:
            pass
    return (0,0)

def gerar_poligonos(df_base, col_agrup, eps, min_samples):
    grupos = df_base.groupby(col_agrup)
    resultados = []
    for grupo_val, grupo in grupos:
        pontos = grupo[['latitude','longitude']].values
        if len(pontos) < 3:
            continue
        clustering = DBSCAN(eps=eps, min_samples=min_samples).fit(pontos)
        for label in set(clustering.labels_):
            if label == -1:
                continue
            cluster = pontos[clustering.labels_ == label]
            if len(cluster) < 3:
                continue
            try:
                hull = ConvexHull(cluster)
                vertices = cluster[hull.vertices]
                coords = [[lat, lon] for lat, lon in vertices]
                coords.append(coords[0])
                centro = (cluster[:,0].mean(), cluster[:,1].mean())
                resultados.append({
                    'grupo': grupo_val if len(col_agrup) > 1 else (grupo_val,),
                    'coords': coords,
                    'centro': centro
                })
            except:
                continue
    return resultados

def verificar_conflitos(pontos_df, poligonos_livro):
    """Versão corrigida com validação de geometria."""
    if not poligonos_livro:
        return []
    
    # Filtrar polígonos válidos
    pol_geoms = []
    pol_info_list = []
    for p in poligonos_livro:
        try:
            if 'coords' not in p:
                continue
            coords = p['coords']
            if len(coords) < 3:
                continue
            poly = Polygon(coords)
            if poly.is_valid:
                pol_geoms.append(poly)
                pol_info_list.append(p)
        except Exception:
            continue
    
    if not pol_geoms:
        return []
    
    tree = STRtree(pol_geoms)
    conflitos = []
    for _, ponto in pontos_df.iterrows():
        try:
            pt = Point(ponto['latitude'], ponto['longitude'])
            possiveis = tree.query(pt)
            for geom in possiveis:
                if geom.contains(pt):
                    idx = pol_geoms.index(geom)
                    pol_info = pol_info_list[idx]
                    livro_correto = pol_info['grupo'][0]
                    if ponto['livro'] != livro_correto:
                        conflitos.append({
                            'uc': ponto['uc'],
                            'endereco': ponto['endereco'],
                            'livro_informado': ponto['livro'],
                            'livro_correto': livro_correto,
                            'area': pol_info['grupo'][1] if len(pol_info['grupo']) > 1 else None,
                            'latitude': ponto['latitude'],
                            'longitude': ponto['longitude'],
                            'base': ponto['base']
                        })
                    break
        except Exception as e:
            print(f"Erro ao verificar ponto {ponto.get('uc', 'desconhecido')}: {e}")
            continue
    return conflitos

def processar(progress_var, status_label, params):
    try:
        status_label.config(text="Validando e carregando dados...")
        progress_var.set(5)

        # 1. BD_CBA
        df_bd = pd.read_excel(params['caminho_principal'], sheet_name=params['aba_bd'])
        df_bd = df_bd[[params['col_uc_bd'], params['col_lat_bd'], params['col_lon_bd'],
                       params['col_end_bd'], params['col_roteiro']]].copy()
        df_bd.columns = ['uc', 'latitude', 'longitude', 'endereco', 'roteiro']
        df_bd['latitude'] = df_bd['latitude'].apply(converter_coord)
        df_bd['longitude'] = df_bd['longitude'].apply(converter_coord)
        df_bd.dropna(subset=['latitude','longitude'], inplace=True)
        df_bd = df_bd[(df_bd['latitude'].between(-90,90)) & (df_bd['longitude'].between(-180,180))]
        df_bd[['livro','area']] = df_bd['roteiro'].apply(lambda x: pd.Series(extrair_livro_area(x)))
        df_bd = df_bd[df_bd['livro'] > 0]
        df_bd['base'] = 'BD_CBA'

        # 2. Segmentação
        df_seg = pd.read_excel(params['caminho_seg'], sheet_name=params['aba_seg'])
        df_seg = df_seg.rename(columns={
            params['col_cod_area']: 'cod_area',
            params['col_nome_area']: 'nome_area',
            params['col_polo']: 'polo'
        })
        df_seg['cod_area'] = pd.to_numeric(df_seg['cod_area'], errors='coerce').fillna(0).astype(int)

        df_bd = df_bd.merge(df_seg[['cod_area','polo','nome_area']], left_on='area', right_on='cod_area', how='left')
        df_bd = df_bd.dropna(subset=['polo'])
        if df_bd.empty:
            messagebox.showerror("Erro", "Nenhuma UC com polo associado. Verifique o mapeamento.")
            return

        # 3. Bases de comparação
        progress_var.set(20)
        df_comp = pd.DataFrame()
        if params['incluir_fora']:
            df_fora = pd.read_excel(params['caminho_principal'], sheet_name='FORA_ROTA')
            df_fora = df_fora[[params['col_uc_fora'], params['col_lat_fora'], params['col_lon_fora'],
                               params['col_end_fora'], params['col_livro_fora']]].copy()
            df_fora.columns = ['uc', 'latitude', 'longitude', 'endereco', 'livro']
            df_fora['latitude'] = df_fora['latitude'].apply(converter_coord)
            df_fora['longitude'] = df_fora['longitude'].apply(converter_coord)
            df_fora.dropna(subset=['latitude','longitude'], inplace=True)
            df_fora['livro'] = pd.to_numeric(df_fora['livro'], errors='coerce').fillna(0).astype(int)
            df_fora['base'] = 'FORA_ROTA'
            df_comp = pd.concat([df_comp, df_fora], ignore_index=True)
        if params['incluir_lig']:
            df_lig = pd.read_excel(params['caminho_principal'], sheet_name='LIGACOES_NOVAS')
            df_lig = df_lig[[params['col_uc_lig'], params['col_lat_lig'], params['col_lon_lig'],
                             params['col_end_lig'], params['col_livro_lig']]].copy()
            df_lig.columns = ['uc', 'latitude', 'longitude', 'endereco', 'livro']
            df_lig['latitude'] = df_lig['latitude'].apply(converter_coord)
            df_lig['longitude'] = df_lig['longitude'].apply(converter_coord)
            df_lig.dropna(subset=['latitude','longitude'], inplace=True)
            df_lig['livro'] = pd.to_numeric(df_lig['livro'], errors='coerce').fillna(0).astype(int)
            df_lig['base'] = 'LIGACOES_NOVAS'
            df_comp = pd.concat([df_comp, df_lig], ignore_index=True)

        # 4. Gerar polígonos
        status_label.config(text="Gerando polígonos...")
        progress_var.set(40)
        polos = df_bd['polo'].unique()
        todos_poligonos_area = []
        todos_poligonos_livro = []
        total_polos = len(polos)
        for i, polo in enumerate(polos):
            status_label.config(text=f"Processando polo {polo} ({i+1}/{total_polos})...")
            progress_var.set(40 + int(30 * i / total_polos))
            df_polo = df_bd[df_bd['polo'] == polo]
            pol_area = gerar_poligonos(df_polo, ['area'], params['eps'], params['min_samples'])
            for p in pol_area:
                area_id = p['grupo'][0]
                nome = df_seg[df_seg['cod_area']==area_id]['nome_area'].values
                nome_area = nome[0] if len(nome)>0 else f"Área {area_id}"
                todos_poligonos_area.append({
                    'polo': polo, 'area_id': area_id, 'nome_area': nome_area,
                    'coords': p['coords'], 'centro': p['centro']
                })
            pol_livro = gerar_poligonos(df_polo, ['livro','area'], params['eps'], params['min_samples'])
            for p in pol_livro:
                livro = p['grupo'][0]
                area_id = p['grupo'][1]
                todos_poligonos_livro.append({
                    'polo': polo, 'livro': livro, 'area_id': area_id,
                    'coords': p['coords'], 'centro': p['centro']
                })
        
        # Filtrar polígonos de livro inválidos (para evitar erro no conflito)
        todos_poligonos_livro_validos = []
        for p in todos_poligonos_livro:
            try:
                if len(p['coords']) >= 3:
                    poly = Polygon(p['coords'])
                    if poly.is_valid:
                        todos_poligonos_livro_validos.append(p)
            except:
                pass
        todos_poligonos_livro = todos_poligonos_livro_validos

        # 5. Conflitos
        status_label.config(text="Verificando conflitos...")
        progress_var.set(80)
        conflitos = []
        if not df_comp.empty and todos_poligonos_livro:
            for polo in polos:
                pol_livro_polo = [p for p in todos_poligonos_livro if p['polo'] == polo]
                if pol_livro_polo:
                    conflitos.extend(verificar_conflitos(df_comp, pol_livro_polo))

        # 6. Mapa
        status_label.config(text="Construindo mapa...")
        progress_var.set(90)
        centro_lat = df_bd['latitude'].mean()
        centro_lon = df_bd['longitude'].mean()
        mapa = folium.Map(location=[centro_lat, centro_lon], zoom_start=10, control_scale=True)
        folium.LayerControl().add_to(mapa)

        for p in todos_poligonos_area:
            folium.Polygon(locations=p['coords'], color="black", weight=3, fill=False,
                           popup=f"Área {p['area_id']} - {p['nome_area']}", tooltip=p['nome_area']).add_to(mapa)

        for p in todos_poligonos_livro:
            cor = COR_POR_LIVRO.get(p['livro'], "#888888")
            folium.Polygon(locations=p['coords'], color=cor, weight=2, fill=True,
                           fill_color=cor, fill_opacity=0.25,
                           popup=f"Livro {p['livro']} - Área {p['area_id']}", tooltip=f"Livro {p['livro']}").add_to(mapa)

        for _, row in df_bd.iterrows():
            cor = COR_POR_LIVRO.get(row['livro'], "#888888")
            folium.CircleMarker(location=[row['latitude'], row['longitude']], radius=5,
                                color=cor, fill=True, fill_color=cor, fill_opacity=0.8,
                                tooltip=f"UC: {row['uc']} | Livro {row['livro']} | Área {row['area']} | {row['endereco']}",
                                popup=row['uc']).add_to(mapa)

        for _, row in df_comp.iterrows():
            cor = COR_POR_LIVRO.get(row['livro'], "#888888")
            conflito = next((c for c in conflitos if c['uc'] == row['uc'] and c['base'] == row['base']), None)
            if conflito:
                folium.CircleMarker(location=[row['latitude'], row['longitude']], radius=8, color='red', weight=3,
                                    fill=True, fill_color='red', fill_opacity=0.6,
                                    tooltip=f"⚠️ CONFLITO: {row['base']} - {row['uc']} (Livro {row['livro']}) -> Correto: Livro {conflito['livro_correto']}",
                                    popup=row['uc']).add_to(mapa)
            else:
                folium.CircleMarker(location=[row['latitude'], row['longitude']], radius=6, color='black', weight=1,
                                    fill=True, fill_color=cor, fill_opacity=0.7,
                                    tooltip=f"{row['base']}: {row['uc']} (Livro {row['livro']})",
                                    popup=row['uc']).add_to(mapa)

        # Filtro por polo
        polo_list = sorted(df_bd['polo'].unique())
        dropdown_html = f'''
        <div style="position: fixed; top: 10px; right: 10px; z-index: 1000; background-color: white; padding: 10px; border-radius: 5px; border: 1px solid #ccc; box-shadow: 2px 2px 5px rgba(0,0,0,0.2);">
            <label for="polo-select">Filtrar por Polo:</label>
            <select id="polo-select" style="margin-left: 5px; padding: 5px;">
                <option value="todos">Todos os Polos</option>
                {''.join(f'<option value="{p}">{p}</option>' for p in polo_list)}
            </select>
        </div>
        <script>
        document.addEventListener('DOMContentLoaded', function() {{
            var map = window.map;
            if (!map) map = document.querySelector('.folium-map').__folium_map;
            var geoJsonLayers = [];
            function collectLayers(layer) {{
                if (layer instanceof L.GeoJSON) geoJsonLayers.push(layer);
                if (layer.eachLayer) layer.eachLayer(collectLayers);
            }}
            map.eachLayer(collectLayers);
            function filterByPolo(polo) {{
                geoJsonLayers.forEach(function(layer) {{
                    layer.eachLayer(function(featureLayer) {{
                        var props = featureLayer.feature && featureLayer.feature.properties;
                        if (!props) return;
                        if (polo === 'todos') {{
                            featureLayer.setStyle({{ opacity: 1, fillOpacity: 0.2 }});
                        }} else {{
                            if (props.polo === polo) {{
                                featureLayer.setStyle({{ opacity: 1, fillOpacity: 0.2 }});
                            }} else {{
                                featureLayer.setStyle({{ opacity: 0, fillOpacity: 0 }});
                            }}
                        }}
                    }});
                }});
            }}
            document.getElementById('polo-select').addEventListener('change', function(e) {{
                filterByPolo(e.target.value);
            }});
            filterByPolo('todos');
        }});
        </script>
        '''
        mapa.get_root().html.add_child(folium.Element(dropdown_html))

        mapa.save(params['saida'])
        progress_var.set(100)
        status_label.config(text="Concluído!")
        messagebox.showinfo("Sucesso", f"Mapa gerado com sucesso:\n{params['saida']}")
    except Exception as e:
        messagebox.showerror("Erro", f"Ocorreu um erro:\n{str(e)}")
        status_label.config(text="Erro na execução")
        progress_var.set(0)

# =============================================================================
# INTERFACE GRÁFICA (mantida igual à versão anterior com comboboxes)
# =============================================================================
class Aplicacao:
    def __init__(self, root):
        self.root = root
        root.title("Gerador de Mapa de UCs por Polo - Mapeamento Automático")
        root.geometry("900x800")
        root.resizable(True, True)

        self.caminho_principal = tk.StringVar()
        self.caminho_seg = tk.StringVar()
        self.aba_bd = tk.StringVar()
        self.aba_seg = tk.StringVar()

        self.colunas_bd = []
        self.colunas_seg = []
        self.colunas_fora = []
        self.colunas_lig = []

        self.col_uc_bd = tk.StringVar()
        self.col_lat_bd = tk.StringVar()
        self.col_lon_bd = tk.StringVar()
        self.col_end_bd = tk.StringVar()
        self.col_roteiro = tk.StringVar()

        self.col_cod_area = tk.StringVar()
        self.col_nome_area = tk.StringVar()
        self.col_polo = tk.StringVar()

        self.incluir_fora = tk.BooleanVar(value=True)
        self.col_uc_fora = tk.StringVar()
        self.col_lat_fora = tk.StringVar()
        self.col_lon_fora = tk.StringVar()
        self.col_end_fora = tk.StringVar()
        self.col_livro_fora = tk.StringVar()

        self.incluir_lig = tk.BooleanVar(value=True)
        self.col_uc_lig = tk.StringVar()
        self.col_lat_lig = tk.StringVar()
        self.col_lon_lig = tk.StringVar()
        self.col_end_lig = tk.StringVar()
        self.col_livro_lig = tk.StringVar()

        self.eps = tk.DoubleVar(value=EPS_DEFAULT)
        self.min_samples = tk.IntVar(value=MIN_SAMPLES_DEFAULT)
        self.saida = tk.StringVar(value="mapa_polos_filtravel.html")

        self.criar_widgets()

    def criar_widgets(self):
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill='both', expand=True, padx=5, pady=5)

        aba1 = ttk.Frame(notebook)
        notebook.add(aba1, text="1. Arquivos")
        self.criar_aba_arquivos(aba1)

        self.aba2 = ttk.Frame(notebook)
        notebook.add(self.aba2, text="2. BD_CBA")
        self.criar_aba_bd_dinamica()

        self.aba3 = ttk.Frame(notebook)
        notebook.add(self.aba3, text="3. Segmentação")
        self.criar_aba_seg_dinamica()

        self.aba4 = ttk.Frame(notebook)
        notebook.add(self.aba4, text="4. Comparação")
        self.criar_aba_comparacao_dinamica()

        aba5 = ttk.Frame(notebook)
        notebook.add(aba5, text="5. Gerar Mapa")
        self.criar_aba_execucao(aba5)

    def criar_aba_arquivos(self, parent):
        frame = ttk.Frame(parent, padding=10)
        frame.pack(fill='x')

        ttk.Label(frame, text="Arquivo principal (com abas BD_CBA, FORA_ROTA, LIGACOES_NOVAS):").grid(row=0, column=0, sticky='w', pady=5)
        ttk.Entry(frame, textvariable=self.caminho_principal, width=70).grid(row=0, column=1, padx=5)
        ttk.Button(frame, text="Procurar...", command=self.selecionar_principal).grid(row=0, column=2)
        ttk.Button(frame, text="Carregar Abas e Colunas", command=self.carregar_abas_principal).grid(row=0, column=3, padx=5)

        ttk.Label(frame, text="Aba BD_CBA:").grid(row=1, column=0, sticky='w', pady=5)
        self.combo_aba_bd = ttk.Combobox(frame, textvariable=self.aba_bd, width=30)
        self.combo_aba_bd.grid(row=1, column=1, sticky='w')
        self.combo_aba_bd.bind('<<ComboboxSelected>>', self.atualizar_colunas_bd)

        ttk.Label(frame, text="Arquivo de segmentação:").grid(row=2, column=0, sticky='w', pady=5)
        ttk.Entry(frame, textvariable=self.caminho_seg, width=70).grid(row=2, column=1, padx=5)
        ttk.Button(frame, text="Procurar...", command=self.selecionar_seg).grid(row=2, column=2)
        ttk.Button(frame, text="Carregar Abas e Colunas", command=self.carregar_abas_seg).grid(row=2, column=3, padx=5)

        ttk.Label(frame, text="Aba segmentação:").grid(row=3, column=0, sticky='w', pady=5)
        self.combo_aba_seg = ttk.Combobox(frame, textvariable=self.aba_seg, width=30)
        self.combo_aba_seg.grid(row=3, column=1, sticky='w')
        self.combo_aba_seg.bind('<<ComboboxSelected>>', self.atualizar_colunas_seg)

    def criar_aba_bd_dinamica(self):
        for widget in self.aba2.winfo_children():
            widget.destroy()
        frame = ttk.Frame(self.aba2, padding=10)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text="Mapeamento da BD_CBA - Selecione as colunas:").pack(anchor='w', pady=5)
        self.bd_uc_combo = self.criar_combobox(frame, "UC:", self.col_uc_bd, self.colunas_bd)
        self.bd_lat_combo = self.criar_combobox(frame, "LATITUDE:", self.col_lat_bd, self.colunas_bd)
        self.bd_lon_combo = self.criar_combobox(frame, "LONGITUDE:", self.col_lon_bd, self.colunas_bd)
        self.bd_end_combo = self.criar_combobox(frame, "ENDEREÇO:", self.col_end_bd, self.colunas_bd)
        self.bd_rot_combo = self.criar_combobox(frame, "ROTEIRO (livro/area/rota):", self.col_roteiro, self.colunas_bd)
        ttk.Button(frame, text="Sugerir automático", command=self.sugerir_colunas_bd).pack(pady=10)

    def criar_aba_seg_dinamica(self):
        for widget in self.aba3.winfo_children():
            widget.destroy()
        frame = ttk.Frame(self.aba3, padding=10)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text="Mapeamento da Segmentação - Selecione as colunas:").pack(anchor='w', pady=5)
        self.seg_cod_combo = self.criar_combobox(frame, "Código da área:", self.col_cod_area, self.colunas_seg)
        self.seg_nome_combo = self.criar_combobox(frame, "Nome da área:", self.col_nome_area, self.colunas_seg)
        self.seg_polo_combo = self.criar_combobox(frame, "POLO:", self.col_polo, self.colunas_seg)
        ttk.Button(frame, text="Sugerir automático", command=self.sugerir_colunas_seg).pack(pady=10)

    def criar_aba_comparacao_dinamica(self):
        for widget in self.aba4.winfo_children():
            widget.destroy()
        frame = ttk.Frame(self.aba4, padding=10)
        frame.pack(fill='both', expand=True)

        var_fora = self.incluir_fora
        cb = ttk.Checkbutton(frame, text="Incluir FORA_ROTA", variable=var_fora, command=self.toggle_fora)
        cb.pack(anchor='w')
        self.frame_fora = ttk.Frame(frame)
        self.frame_fora.pack(fill='x', pady=5)
        self.criar_campos_comparacao_dinamica(self.frame_fora, "FORA_ROTA",
                                              self.col_uc_fora, self.col_lat_fora, self.col_lon_fora,
                                              self.col_end_fora, self.col_livro_fora, self.colunas_fora)
        if self.incluir_fora.get():
            self.frame_fora.pack(fill='x', pady=5)
        else:
            self.frame_fora.pack_forget()

        var_lig = self.incluir_lig
        cb = ttk.Checkbutton(frame, text="Incluir LIGACOES_NOVAS", variable=var_lig, command=self.toggle_lig)
        cb.pack(anchor='w', pady=(10,0))
        self.frame_lig = ttk.Frame(frame)
        self.frame_lig.pack(fill='x', pady=5)
        self.criar_campos_comparacao_dinamica(self.frame_lig, "LIGACOES_NOVAS",
                                              self.col_uc_lig, self.col_lat_lig, self.col_lon_lig,
                                              self.col_end_lig, self.col_livro_lig, self.colunas_lig)
        if self.incluir_lig.get():
            self.frame_lig.pack(fill='x', pady=5)
        else:
            self.frame_lig.pack_forget()

    def criar_campos_comparacao_dinamica(self, parent, nome, var_uc, var_lat, var_lon, var_end, var_livro, colunas):
        ttk.Label(parent, text=f"Mapeamento para {nome}:").pack(anchor='w')
        self.criar_combobox(parent, "UC:", var_uc, colunas, pack_side=True)
        self.criar_combobox(parent, "LATITUDE:", var_lat, colunas, pack_side=True)
        self.criar_combobox(parent, "LONGITUDE:", var_lon, colunas, pack_side=True)
        self.criar_combobox(parent, "ENDEREÇO:", var_end, colunas, pack_side=True)
        self.criar_combobox(parent, "LIVRO:", var_livro, colunas, pack_side=True)
        ttk.Button(parent, text=f"Sugerir automático para {nome}",
                   command=lambda: self.sugerir_colunas_comparacao(nome, var_uc, var_lat, var_lon, var_end, var_livro)).pack(pady=5)

    def criar_combobox(self, parent, label, variable, values_list, pack_side=False):
        frame = ttk.Frame(parent)
        frame.pack(anchor='w', pady=2, fill='x')
        ttk.Label(frame, text=label, width=15).pack(side='left')
        combo = ttk.Combobox(frame, textvariable=variable, values=values_list, width=40)
        combo.pack(side='left', padx=5)
        if values_list:
            combo.set('')
        return combo

    def toggle_fora(self):
        if self.incluir_fora.get():
            self.frame_fora.pack(fill='x', pady=5)
        else:
            self.frame_fora.pack_forget()

    def toggle_lig(self):
        if self.incluir_lig.get():
            self.frame_lig.pack(fill='x', pady=5)
        else:
            self.frame_lig.pack_forget()

    def criar_aba_execucao(self, parent):
        frame = ttk.Frame(parent, padding=10)
        frame.pack(fill='x')
        ttk.Label(frame, text="Parâmetros DBSCAN:").pack(anchor='w')
        ttk.Label(frame, text="EPS (raio em graus):").pack(anchor='w')
        ttk.Entry(frame, textvariable=self.eps, width=20).pack(anchor='w')
        ttk.Label(frame, text="Mínimo de pontos por cluster:").pack(anchor='w')
        ttk.Entry(frame, textvariable=self.min_samples, width=20).pack(anchor='w')
        ttk.Label(frame, text="Arquivo de saída (HTML):").pack(anchor='w', pady=(10,0))
        ttk.Entry(frame, textvariable=self.saida, width=70).pack(anchor='w')
        ttk.Button(frame, text="Procurar...", command=self.selecionar_saida).pack(anchor='w', pady=5)
        self.progress_var = tk.IntVar(value=0)
        self.progress = ttk.Progressbar(frame, orient='horizontal', length=400, mode='determinate', variable=self.progress_var)
        self.progress.pack(pady=20)
        self.status_label = ttk.Label(frame, text="Aguardando...")
        self.status_label.pack()
        ttk.Button(frame, text="▶ GERAR MAPA", command=self.executar, width=20).pack(pady=20)

    # --- Funções auxiliares ---
    def selecionar_principal(self):
        path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls")])
        if path:
            self.caminho_principal.set(path)

    def selecionar_seg(self):
        path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls")])
        if path:
            self.caminho_seg.set(path)

    def selecionar_saida(self):
        path = filedialog.asksaveasfilename(defaultextension=".html", filetypes=[("HTML files", "*.html")])
        if path:
            self.saida.set(path)

    def carregar_abas_principal(self):
        if not self.caminho_principal.get():
            messagebox.showwarning("Aviso", "Selecione o arquivo principal primeiro.")
            return
        try:
            xl = pd.ExcelFile(self.caminho_principal.get())
            self.combo_aba_bd['values'] = xl.sheet_names
            if 'BD_CBA' in xl.sheet_names:
                self.aba_bd.set('BD_CBA')
            else:
                self.aba_bd.set(xl.sheet_names[0])
            self.atualizar_colunas_bd()
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao ler arquivo: {e}")

    def carregar_abas_seg(self):
        if not self.caminho_seg.get():
            messagebox.showwarning("Aviso", "Selecione o arquivo de segmentação.")
            return
        try:
            xl = pd.ExcelFile(self.caminho_seg.get())
            self.combo_aba_seg['values'] = xl.sheet_names
            if xl.sheet_names:
                self.aba_seg.set(xl.sheet_names[0])
            self.atualizar_colunas_seg()
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao ler arquivo: {e}")

    def atualizar_colunas_bd(self, event=None):
        if not self.caminho_principal.get() or not self.aba_bd.get():
            return
        try:
            df = pd.read_excel(self.caminho_principal.get(), sheet_name=self.aba_bd.get(), nrows=1)
            self.colunas_bd = list(df.columns)
            self.criar_aba_bd_dinamica()
            self.atualizar_colunas_comparacao()
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao ler colunas da BD_CBA: {e}")

    def atualizar_colunas_seg(self, event=None):
        if not self.caminho_seg.get() or not self.aba_seg.get():
            return
        try:
            df = pd.read_excel(self.caminho_seg.get(), sheet_name=self.aba_seg.get(), nrows=1)
            self.colunas_seg = list(df.columns)
            self.criar_aba_seg_dinamica()
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao ler colunas da segmentação: {e}")

    def atualizar_colunas_comparacao(self):
        if not self.caminho_principal.get():
            return
        try:
            xl = pd.ExcelFile(self.caminho_principal.get())
            if 'FORA_ROTA' in xl.sheet_names:
                df = pd.read_excel(self.caminho_principal.get(), sheet_name='FORA_ROTA', nrows=1)
                self.colunas_fora = list(df.columns)
            else:
                self.colunas_fora = []
            if 'LIGACOES_NOVAS' in xl.sheet_names:
                df = pd.read_excel(self.caminho_principal.get(), sheet_name='LIGACOES_NOVAS', nrows=1)
                self.colunas_lig = list(df.columns)
            else:
                self.colunas_lig = []
            self.criar_aba_comparacao_dinamica()
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao ler colunas das bases de comparação: {e}")

    def sugerir_colunas_bd(self):
        if not self.colunas_bd:
            messagebox.showwarning("Aviso", "Carregue as colunas da BD_CBA primeiro.")
            return
        col_uc = self._encontrar_coluna(['NUMCDC_ITC', 'UC', 'NUMCDC', 'CONSUMIDOR'])
        col_lat = self._encontrar_coluna(['VRLIT_PTO_ETG_CVR', 'LATITUDE', 'LAT'])
        col_lon = self._encontrar_coluna(['VLRLGT_PTO_ETG_CVR', 'LONGITUDE', 'LON'])
        col_end = self._encontrar_coluna(['BAIRRO', 'ENDERECO', 'END'])
        col_rot = self._encontrar_coluna(['ROTEIRO'])
        if col_uc: self.col_uc_bd.set(col_uc)
        if col_lat: self.col_lat_bd.set(col_lat)
        if col_lon: self.col_lon_bd.set(col_lon)
        if col_end: self.col_end_bd.set(col_end)
        if col_rot: self.col_roteiro.set(col_rot)
        messagebox.showinfo("Sugestão", "Mapeamento da BD_CBA sugerido. Verifique se está correto.")

    def sugerir_colunas_seg(self):
        if not self.colunas_seg:
            messagebox.showwarning("Aviso", "Carregue as colunas da segmentação primeiro.")
            return
        col_cod = self._encontrar_coluna(['COD LOCALIDADE', 'CODIGO LOCALIDADE', 'COD_AREA'], self.colunas_seg)
        col_nome = self._encontrar_coluna(['LOCALIDADE', 'NOME_AREA'], self.colunas_seg)
        col_polo = self._encontrar_coluna(['POLO'], self.colunas_seg)
        if col_cod: self.col_cod_area.set(col_cod)
        if col_nome: self.col_nome_area.set(col_nome)
        if col_polo: self.col_polo.set(col_polo)
        messagebox.showinfo("Sugestão", "Mapeamento da segmentação sugerido.")

    def sugerir_colunas_comparacao(self, nome_aba, var_uc, var_lat, var_lon, var_end, var_livro):
        if nome_aba == 'FORA_ROTA':
            colunas = self.colunas_fora
        else:
            colunas = self.colunas_lig
        if not colunas:
            messagebox.showwarning("Aviso", f"Carregue as colunas da {nome_aba} primeiro.")
            return
        col_uc = self._encontrar_coluna(['NUMCDC', 'UC'], colunas)
        col_lat = self._encontrar_coluna(['VRLIT_PTO_ETG_CVR', 'LATITUDE', 'LAT'], colunas)
        col_lon = self._encontrar_coluna(['VLRLGT_PTO_ETG_CVR', 'LONGITUDE', 'LON'], colunas)
        col_end = self._encontrar_coluna(['BAIRRO', 'ENDERECO', 'END'], colunas)
        col_liv = self._encontrar_coluna(['NUMLIV', 'LIVRO'], colunas)
        if col_uc: var_uc.set(col_uc)
        if col_lat: var_lat.set(col_lat)
        if col_lon: var_lon.set(col_lon)
        if col_end: var_end.set(col_end)
        if col_liv: var_livro.set(col_liv)
        messagebox.showinfo("Sugestão", f"Mapeamento para {nome_aba} sugerido.")

    def _encontrar_coluna(self, possiveis_nomes, lista_colunas=None):
        if lista_colunas is None:
            lista_colunas = self.colunas_bd
        for nome in possiveis_nomes:
            for col in lista_colunas:
                if nome.upper() == col.upper().strip():
                    return col
        return None

    def executar(self):
        # Validações
        if not self.caminho_principal.get():
            messagebox.showerror("Erro", "Informe o arquivo principal.")
            return
        if not self.aba_bd.get():
            messagebox.showerror("Erro", "Selecione a aba BD_CBA.")
            return
        if not self.col_uc_bd.get() or not self.col_lat_bd.get() or not self.col_lon_bd.get() or not self.col_end_bd.get() or not self.col_roteiro.get():
            messagebox.showerror("Erro", "Preencha todas as colunas da BD_CBA.")
            return
        if not self.caminho_seg.get():
            messagebox.showerror("Erro", "Informe o arquivo de segmentação.")
            return
        if not self.aba_seg.get():
            messagebox.showerror("Erro", "Selecione a aba de segmentação.")
            return
        if not self.col_cod_area.get() or not self.col_nome_area.get() or not self.col_polo.get():
            messagebox.showerror("Erro", "Preencha todas as colunas da segmentação.")
            return
        if self.incluir_fora.get() and (not self.col_uc_fora.get() or not self.col_lat_fora.get() or not self.col_lon_fora.get() or not self.col_end_fora.get() or not self.col_livro_fora.get()):
            messagebox.showerror("Erro", "Preencha todas as colunas do FORA_ROTA.")
            return
        if self.incluir_lig.get() and (not self.col_uc_lig.get() or not self.col_lat_lig.get() or not self.col_lon_lig.get() or not self.col_end_lig.get() or not self.col_livro_lig.get()):
            messagebox.showerror("Erro", "Preencha todas as colunas do LIGACOES_NOVAS.")
            return

        params = {
            'caminho_principal': self.caminho_principal.get(),
            'aba_bd': self.aba_bd.get(),
            'col_uc_bd': self.col_uc_bd.get(),
            'col_lat_bd': self.col_lat_bd.get(),
            'col_lon_bd': self.col_lon_bd.get(),
            'col_end_bd': self.col_end_bd.get(),
            'col_roteiro': self.col_roteiro.get(),
            'caminho_seg': self.caminho_seg.get(),
            'aba_seg': self.aba_seg.get(),
            'col_cod_area': self.col_cod_area.get(),
            'col_nome_area': self.col_nome_area.get(),
            'col_polo': self.col_polo.get(),
            'incluir_fora': self.incluir_fora.get(),
            'incluir_lig': self.incluir_lig.get(),
            'eps': self.eps.get(),
            'min_samples': self.min_samples.get(),
            'saida': self.saida.get()
        }
        if self.incluir_fora.get():
            params.update({
                'col_uc_fora': self.col_uc_fora.get(),
                'col_lat_fora': self.col_lat_fora.get(),
                'col_lon_fora': self.col_lon_fora.get(),
                'col_end_fora': self.col_end_fora.get(),
                'col_livro_fora': self.col_livro_fora.get()
            })
        if self.incluir_lig.get():
            params.update({
                'col_uc_lig': self.col_uc_lig.get(),
                'col_lat_lig': self.col_lat_lig.get(),
                'col_lon_lig': self.col_lon_lig.get(),
                'col_end_lig': self.col_end_lig.get(),
                'col_livro_lig': self.col_livro_lig.get()
            })

        for child in self.root.winfo_children():
            if isinstance(child, ttk.Button):
                child.config(state='disabled')
        self.progress_var.set(0)
        self.status_label.config(text="Iniciando...")
        thread = threading.Thread(target=processar, args=(self.progress_var, self.status_label, params))
        thread.start()
        def check_thread():
            if thread.is_alive():
                self.root.after(100, check_thread)
            else:
                for child in self.root.winfo_children():
                    if isinstance(child, ttk.Button):
                        child.config(state='normal')
        self.root.after(100, check_thread)

if __name__ == "__main__":
    root = tk.Tk()
    app = Aplicacao(root)
    root.mainloop()